﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETBA_Entities;
using ETBAException;

namespace ETBA_DAL
{
  public  class AdminDal
    {
        static string ConnectionString = GlobalData.ConnectionString;
        SqlConnection connection = new SqlConnection();
        public bool AddEmployeDal(Users addemp)
        {
            bool isEmployeeadded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[ETBA].[SP_AddEmployee]";
                Command.Parameters.AddWithValue("@EmployeeName", addemp.EmployeeName);
                Command.Parameters.AddWithValue("@LoginId", addemp.LoginId);
                Command.Parameters.AddWithValue("@Password", addemp.Password);
                Command.Parameters.AddWithValue("@ManagerUserId", addemp.ManagerUserId);
                Command.Parameters.AddWithValue("@UserTypeId", addemp.UserTypeId);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isEmployeeadded = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return isEmployeeadded;
        }
        public bool AddManagerDal(Manager addmanager)
        {
            bool isManageradded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[ETBA].[sp_addmanager]";
                Command.Parameters.AddWithValue("@ManagerName", addmanager.ManagerName);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isManageradded = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return isManageradded;
        }
        public bool AddTravelAgentDal(TravelAgent addtravelagent)
        {
            bool istravelagentadded = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.Sp_travelagentdetails";

                Command.Parameters.AddWithValue("@Name", addtravelagent.Name);
                Command.Parameters.AddWithValue("@Password ", addtravelagent.Password);

                Command.Parameters.AddWithValue("@AgencyName  ", addtravelagent.AgencyName);


                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    istravelagentadded = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return istravelagentadded;
        }
        public bool EditEmployee(Users editemp)
        {
            bool isemployeeedited = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[ETBA].[SP_UpdateEmployee]";
                Command.Parameters.AddWithValue("@EmployeeId", editemp.EmployeeId);
                Command.Parameters.AddWithValue("@EmployeeName", editemp.EmployeeName);
                Command.Parameters.AddWithValue("@LoginId", editemp.LoginId);
                Command.Parameters.AddWithValue("@Password", editemp.Password);
                Command.Parameters.AddWithValue("@ManagerUserId", editemp.ManagerUserId);
                Command.Parameters.AddWithValue("@UserTypeId", editemp.UserTypeId);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    isemployeeedited = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return isemployeeedited;

        }
        public Users searchEmployeeDal(int Employeeid)
        {
            Users name = new Users();
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "[ETBA].[SP_SearchEmployee]";
                Command.Parameters.AddWithValue("@EmployeeId", Employeeid);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {

                        name.LoginId = Int32.Parse(Reader[2].ToString());
                        name.EmployeeName = Reader[1].ToString();
                        name.Password = Reader[3].ToString();
                        name.ManagerUserId = Int32.Parse(Reader[4].ToString());
                        name.UserTypeId = Int32.Parse(Reader[5].ToString());
                    }
                }
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return name;

        }
        public Manager searchManagerDal(int managerid)
        {
            Manager name = new Manager();
            try

            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.SearchManager";
                Command.Parameters.AddWithValue("@Managerid", managerid);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {
                        name.ManagerId = Int32.Parse(Reader[0].ToString());
                        name.ManagerName = Reader[1].ToString();

                    }
                }
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return name;

        }
        public bool UpdateManager(Manager updatemanager)
        {
            bool ismanagerUpdated = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.EDitManagerByid";
                Command.Parameters.AddWithValue("@Managerid", updatemanager.ManagerId);
                Command.Parameters.AddWithValue("@ManagerName", updatemanager.ManagerName);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    ismanagerUpdated = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return ismanagerUpdated;

        }

        public TravelAgent searchTravelAgentDal(int travelid)
        {
            TravelAgent tg = new TravelAgent();
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.SearchTravelagentdetailsbyid";
                Command.Parameters.AddWithValue("@Travelid", travelid);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {

                        tg.Name = Reader[1].ToString();
                        tg.Password = Reader[2].ToString();
                        tg.AgencyName = Reader[3].ToString();

                    }
                }
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return tg;

        }
        public bool EditTravelAgentDal(TravelAgent editravelagent)
        {
            bool istravelagentedited = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.Edittravelagent";
                Command.Parameters.AddWithValue("@Travelid", editravelagent.TravelID);
                Command.Parameters.AddWithValue("@Name", editravelagent.Name);
                Command.Parameters.AddWithValue("@Password ", editravelagent.Password);
                Command.Parameters.AddWithValue("@AgencyName", editravelagent.AgencyName);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    istravelagentedited = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return istravelagentedited;

        }

        public bool DeleteEmployeeDAL(int EmployeeId)
        {
            bool isEmployeedeleted = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.DelEmployeebyid";

                Command.Parameters.AddWithValue("@EmployeeId", EmployeeId);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsdeleted = Command.ExecuteNonQuery();
                if (NumberOfRowsdeleted == 1)
                    isEmployeedeleted = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isEmployeedeleted;

        }
    }
}
