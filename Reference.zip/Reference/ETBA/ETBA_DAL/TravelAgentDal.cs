﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETBAException;
using ETBA_Entities;
using System.Data.SqlClient;

namespace ETBA_DAL
{
  public class TravelAgentDal
    {
        static string ConnectionString = GlobalData.ConnectionString;
        SqlConnection connection = new SqlConnection();
        public bool ConformTicketBookingDal(TravelRequests updateticketstatus)
        {
            bool isstatusupdated = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.SP_UpdateTicketBookingStatus";
                Command.Parameters.AddWithValue("@RequestId", updateticketstatus.RequestId);
                Command.Parameters.AddWithValue("@BookingStatus", updateticketstatus.BookingStatus);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded >= 1)
                    isstatusupdated = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return isstatusupdated;

        }
    }
}
