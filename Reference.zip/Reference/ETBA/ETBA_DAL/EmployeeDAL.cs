﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETBA_Entities;
using ETBAException;

namespace ETBA_DAL
{
 public class EmployeeDAL
    {
        static string ConnectionString = GlobalData.ConnectionString;
        SqlConnection connection = new SqlConnection();
        public bool EmployeeRaiseTravelRequestDAl(TravelRequests  raiserequest)
        {
            bool istravelRequestraised = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.GenerateTravelRequest";
                Command.Parameters.AddWithValue("@RequestDate", raiserequest.RequestDate);
                Command.Parameters.AddWithValue("@FromLocation", raiserequest.FromLocation);
                Command.Parameters.AddWithValue("@ToLocation", raiserequest.ToLocation);
                Command.Parameters.AddWithValue("@EmployeeId", raiserequest.EmployeeId);
                Command.Parameters.AddWithValue("@EmployeeName ", raiserequest.EmployeeName);
                Command.Parameters.AddWithValue("@Numberofdays", raiserequest.NumberofDays);
                Command.Parameters.AddWithValue("@TravelPurpose", raiserequest.TravelPurpose);
                Command.Parameters.AddWithValue("@ManagerId", raiserequest.ManagerId);
                Command.Parameters.AddWithValue("@Currentstatus", raiserequest.CurrentStatus);
                Command.Parameters.AddWithValue("@BookingStatus", raiserequest.BookingStatus);




                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                    istravelRequestraised = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return istravelRequestraised;
        }

          public TravelRequests travelRequestsstatusdal(int requestid)
        {
            TravelRequests travelrequests = new TravelRequests();
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.employeecheckstatus";
                Command.Parameters.AddWithValue("@RequestId",requestid);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                SqlDataReader Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    while (Reader.Read())
                    {

                     // travelrequests.RequestId = Int32.Parse(Reader[0].ToString());
                      travelrequests.EmployeeId = Int32.Parse(Reader[0].ToString());
                        travelrequests.CurrentStatus = Reader[1].ToString();
                       
                    }
                }
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return travelrequests;

        }

        public bool CancelTravelRequest(int Requestid)
        {
            bool isrequestcancelled = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.CancelTravelRequest";

                Command.Parameters.AddWithValue("@RequestId",Requestid);
                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsdeleted = Command.ExecuteNonQuery();
                if (NumberOfRowsdeleted == 1)
                    isrequestcancelled = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
            return isrequestcancelled;

        }


    }
}
