﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETBAException;
using ETBA_Entities;
using System.Data.SqlClient;

namespace ETBA_DAL
{
 public class ManagerDal
    {
        static string ConnectionString = GlobalData.ConnectionString;
        SqlConnection connection = new SqlConnection();
        public bool UpdateEmployeeTravelStatusDal(TravelRequests updatestatus)
        {
            bool isstatusupdated = false;
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.SP_UpdateStatus";
                Command.Parameters.AddWithValue("@EmployeeId", updatestatus.EmployeeId);
                Command.Parameters.AddWithValue("@currentStatus", updatestatus.CurrentStatus);

                Command.CommandText = query;
                Command.CommandType = System.Data.CommandType.StoredProcedure;
                int NumberOfRowsAdded = Command.ExecuteNonQuery();
                if (NumberOfRowsAdded >= 1)
                    isstatusupdated = true;
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return isstatusupdated;

        }
    }
}
