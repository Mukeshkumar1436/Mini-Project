﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETBAException
{
   [Serializable]
 public class ETBAException : Exception
      {
            public ETBAException() { }
            public ETBAException(string message) : base(message) { }
            public ETBAException(string message, Exception inner) : base(message, inner) { }
            protected ETBAException(
              System.Runtime.Serialization.SerializationInfo info,
              System.Runtime.Serialization.StreamingContext context) : base(info, context) { }
        }
    }

