﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for TravelAgentLogin.xaml
    /// </summary>
    public partial class TravelAgentLogin : Window
    {
        string constring = ConfigurationManager.ConnectionStrings["Constr"].ConnectionString;
        SqlConnection connection = new SqlConnection();

        public TravelAgentLogin()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, RoutedEventArgs e)
        {
            string constring = ConfigurationManager.ConnectionStrings["Constr"].ConnectionString;
            SqlConnection connection = new SqlConnection(constring);

            try
            {
                connection.Open();
                string query = "select Travelid,Password from ETBA.travelagentdetails where Travelid ='" + txttrvlid.Text + "' and Password='" + txtpswd.Password.ToString() + "' ";
                SqlCommand cmd = new SqlCommand(query, connection);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    if (txttrvlid.Text.Trim() == string.Empty)
                    {
                        MessageBox.Show("TravelId cannot be blank");
                    }
                    else if (txtpswd.Password.Trim() == string.Empty)
                    {
                        MessageBox.Show("password box cannot be empty");

                    }
                    MessageBox.Show("Login Successful!");

                    TravelAgentStatus tag = new TravelAgentStatus();
                    tag.Show();
                    this.Close();
                 
                }
                else
                {
                    MessageBox.Show("Invalid TravelId or Password");
                }

            }
            catch (SqlException)
            {
                throw;
            }


        }

        private void gobacktomainwindow_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
