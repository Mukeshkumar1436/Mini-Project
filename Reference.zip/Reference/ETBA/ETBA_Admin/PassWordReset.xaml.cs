﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for PassWordReset.xaml
    /// </summary>
    public partial class PassWordReset : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        public PassWordReset()
        {
            InitializeComponent();
        }

       
           

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int userid = Int32.Parse(txtUserid.Text);
            int Loginid = Int32.Parse(txtloginid.Text);
            string password = txtpswd.Text;
            try
            {
                SqlConnection.ConnectionString = ConnectionString;
                SqlConnection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = SqlConnection;
                string query = "Update ETBA.Users set LoginId=  "+ Loginid +" ,Password='" + password + "' where UserId=" + userid; 
                command.CommandText = query;
                int NumberOfRowsAdded = command.ExecuteNonQuery();
                if (NumberOfRowsAdded == 1)
                {
                    MessageBox.Show("Employee login details updated Successfully");
                    

                }
                else
                {
                    MessageBox.Show("Failed to update Employee login details details");
                }

            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }

            finally
            {
                if (SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    SqlConnection.Close();
                }
            }



        }
    }
}
