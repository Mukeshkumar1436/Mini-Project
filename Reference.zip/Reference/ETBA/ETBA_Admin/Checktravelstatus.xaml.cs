﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETBA_Entities;
using ETBAException;
using ETBA_BAL;
using System.Data.SqlClient;
using System.Configuration;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for Checktravelstatus.xaml
    /// </summary>
    public partial class Checktravelstatus : Window
    {
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand cmd;
        int employeeid;
        public Checktravelstatus()
        {
            InitializeComponent();
        }
        public Checktravelstatus(int _employeeid)
        {
            InitializeComponent();
            employeeid = _employeeid;
        }
        public void dispdetails()
        {
            try
            {
                connection.ConnectionString = ConnectionString;
                SqlCommand command = new SqlCommand();
                connection.Open();
                command.Connection = connection;
                string query = "[ETBA].[PutDetails1]";

                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandText = query;
                command.Parameters.AddWithValue("@Employeeid", employeeid);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        txtemname.Text = reader[0].ToString();
                        txtassmanaid.Text = reader[1].ToString();
                        txtemploid.Text = reader[2].ToString();

                    }
                }
                else
                {
                    MessageBox.Show("no recored found");
                }
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {

                connection.Close();
            }

        }


        private TravelRequests CheckTravelRequestbyRequestId(int RequestId)
            {
            TravelRequests trrequest = new TravelRequests();
                try
                {
                EmployeeBAL empbal = new EmployeeBAL();
                trrequest = empbal.checktravelstatusbal(RequestId);
                }
                catch (ETBAException.ETBAException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            return trrequest;
            }

        private void btncheck_Click_1(object sender, RoutedEventArgs e)
        {
            int requestid = Int32.Parse(txtreid.Text.ToString());
            TravelRequests chkstatus = CheckTravelRequestbyRequestId(requestid);

            txtempid.Text = chkstatus.EmployeeId.ToString();
            txtxtatus.Text = chkstatus.CurrentStatus;
            lblempid.Visibility = Visibility.Visible;
            txtempid.Visibility = Visibility.Visible;
            lblstatus.Visibility = Visibility.Visible;
            txtxtatus.Visibility = Visibility.Visible;
            if (txtxtatus.Text == "Reject")
            {
                txtRejectBlk.Visibility = Visibility.Visible;
            }
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dispdetails();
        }
    }
    }
