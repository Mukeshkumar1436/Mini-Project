﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

       
        private void hladmin_Click(object sender, RoutedEventArgs e)
        {
            Admin ad = new Admin();
            ad.Show();


        }

        private void hlemployee_Click(object sender, RoutedEventArgs e)
        {
            EmployeeLogin  em = new EmployeeLogin();
            em.Show();
  
        }

        private void hlManager_Click(object sender, RoutedEventArgs e)
        {
            ManagerLogin managerlogin = new ManagerLogin();
            managerlogin.Show();
           
        }

        private void hlTravelAgent_Click(object sender, RoutedEventArgs e)
        {

            TravelAgentLogin TagL = new TravelAgentLogin();
            TagL.Show();
            this.Close();
        }
    }
}
