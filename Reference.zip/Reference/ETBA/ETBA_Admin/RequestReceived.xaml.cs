﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETBA_Entities;
using ETBAException;
using ETBA_BAL;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for RequestReceived.xaml
    /// </summary>
    public partial class RequestReceived : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
    
        public RequestReceived()
        {
            InitializeComponent();
        }
        private void LoadGridViewRequest()
        {
            SqlConnection connection = new SqlConnection();
            try
            {
                connection.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan19_Mumbai;Persist Security Info=True;User ID=sqluser;Password=sqluser";
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = " select * from ETBA.RaiseTravelRequest";
                Command.CommandText = query;
                //SqlDataAdapter sda = new SqlDataAdapter(Command);

                SqlDataReader Reader = Command.ExecuteReader();
                DataTable Table = new DataTable();
                //sda.Fill(Table);
                Table.Load(Reader);
                dtdisplayrequest.DataContext = Table;
                dtdisplayrequest.Visibility = Visibility.Visible;
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Occured:" + Exception.Message);
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Exception Occured:" + Exception.Message);
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }

            }

        }


        private void updatestatus_Click(object sender, RoutedEventArgs e)
        {
       
            if (cmbstatus.Text=="Accept")
            {
                TravelAgentLogin tag = new TravelAgentLogin();
                tag.Show();
                this.Close();


            }
            TravelRequests tr = new TravelRequests();
            tr.EmployeeId = Int32.Parse(txtemployeeid.Text);
            tr.CurrentStatus = cmbstatus.Text;
      

            updatetravelstatu(tr);



        }
        private  void updatetravelstatu(TravelRequests updatestatus)
        {
            SqlConnection connection = new SqlConnection();

            try
            {
                ManagerBal mb = new ManagerBal();
                bool statusupdated = mb.UpdateEmployeeTravelStatusBal(updatestatus);
                if (statusupdated)
                {
                    MessageBox.Show("status Updated  Successfully");

                    LoadGridViewRequest();
                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally{
                if (connection.State == System.Data.ConnectionState.Open)
                {
                   
                    connection.Close();
                    
                }

            }


        }

        private void btnrequest_Click(object sender, RoutedEventArgs e)
        {
            LoadGridViewRequest();
        }
    }




    }