﻿using ETBA_Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETBAException;
using ETBA_BAL;
using System.Data;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for AdminAddEmployee.xaml
    /// </summary>
    public partial class AdminAddEmployee : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        SqlCommand SqlCommand;
        public AdminAddEmployee()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            Users type = new Users();
            //   type.UserId=Int32.Parse(txtuserid.Text);
            type.EmployeeName = txtname.Text;
            type.LoginId = Int32.Parse(txtlogin.Text.ToString());
            type.Password = txtpswd.Password.ToString();
            type.ManagerUserId = Int32.Parse(txtmanageuserid.Text);

            if (CmbUserid.Text == "Employee")
            {
                type.UserTypeId = 2;
            }
            else if (CmbUserid.Text == "Manager")
            {

                type.UserTypeId = 3;

            }
            AddEmployee(type);
        }
        private  void AddEmployee(Users addemp)
        {
            try
            {
                AdminBal addemplo = new AdminBal();
                bool employeeadded = addemplo.AddEmployeeBL(addemp);
                if (employeeadded)
                {
                    MessageBox.Show("employee added Successfully");

                }
                else
                    MessageBox.Show("Details not registered");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection.ConnectionString = ConnectionString;
            SqlCommand = new SqlCommand("select ident_current('ETBA.Users') + ident_incr('ETBA.Users')", SqlConnection);
            try
            {
                SqlConnection.Open();
                object nxId = SqlCommand.ExecuteScalar();
                txtuserid.Text = nxId.ToString();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlConnection.Close();

            }
        }

        private void btnreset_Click(object sender, RoutedEventArgs e)
        {
            txtname.Text = "";
            txtlogin.Text = "";
            txtpswd.Password = "";
            txtmanageuserid.Text = "";
            CmbUserid.Text = "";
        }

        private void disemp_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }

        public void LoadGrid()
        {
            int EmployeeId = Int32.Parse(txtuserid.Text);
            try
            {

                SqlConnection.ConnectionString = ConnectionString;
                SqlConnection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = SqlConnection;
                string query = "SELECT*FROM  ETBA.Users where EmployeeId= " + EmployeeId + "";
                command.CommandText = query;
                SqlDataReader Reader = command.ExecuteReader();
                DataTable Table = new DataTable();
                Table.Load(Reader);
                disemp.DataContext = Table;
                disemp.Visibility = Visibility.Visible;
            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception Occurred." + Exception.Message);
            }
            catch (Exception Exception)
            {

                MessageBox.Show("Exception Occurred." + Exception.Message);
            }
            finally
            {
                if (SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    SqlConnection.Close();
                }

            }



        }

        private void btnview_Click(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }

        private void hladminpowers_Click(object sender, RoutedEventArgs e)
        {
            AdminPowers adp = new AdminPowers();
            adp.Show();
            this.Close();
        }
    }

}
