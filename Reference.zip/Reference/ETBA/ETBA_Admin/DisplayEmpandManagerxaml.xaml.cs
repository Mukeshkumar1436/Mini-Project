﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for DisplayEmpandManagerxaml.xaml
    /// </summary>
    public partial class DisplayEmpandManagerxaml : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        SqlCommand SqlCommand;
        public DisplayEmpandManagerxaml()
        {
            InitializeComponent();
        }
        public void LoadGrid()
        {

            try
            {

                SqlConnection.ConnectionString = ConnectionString;
                SqlConnection.Open();
                SqlCommand command = new SqlCommand();
                command.Connection = SqlConnection;
                string query = "ETBA.Dispalydetails";
                command.CommandText = query;
                SqlDataReader Reader = command.ExecuteReader();
                DataTable Table = new DataTable();
                Table.Load(Reader);
                disempandmanagerdetails.DataContext = Table;
                disempandmanagerdetails.Visibility = Visibility.Visible;
            }
            catch (SqlException Exception)
            {

                MessageBox.Show("Exception Occurred." + Exception.Message);
            }
            catch (Exception Exception)
            {

                MessageBox.Show("Exception Occurred." + Exception.Message);
            }
            finally
            {
                if (SqlConnection.State == System.Data.ConnectionState.Open)
                {
                    SqlConnection.Close();
                }

            }
        }

        private void btndispalydetails_Click(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }
    }
}
