﻿using ETBA_BAL;
using ETBA_Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for AdminEditEmployee.xaml
    /// </summary>
    public partial class AdminEditEmployee : Window
    {

        public AdminEditEmployee()
        {
            InitializeComponent();
        }


        private static void EditEmployee(Users editemp)
        {

            try
            {
                AdminBal editemplo = new AdminBal();
                bool employeeedited = editemplo.UpdateEmployeeBal(editemp);
                if (employeeedited)
                {
                    MessageBox.Show("employee edited Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Users type = new Users();
            type.EmployeeId = Int32.Parse(txtuserid.Text);
            type.EmployeeName = txtName.Text;
            type.LoginId = Int32.Parse(txtLoginId.Text);
            type.Password = txtpswd.Text;
            type.ManagerUserId = Int32.Parse(txtManageUserId.Text);
           
           if (CmbUserid.Text == "Employee")
            {
                type.UserTypeId = 2;
            }
            else if(CmbUserid.Text=="Manager")
            {
                type.UserTypeId = 3;
            }


            EditEmployee(type);
        }

        private void btnsearch_Click(object sender, RoutedEventArgs e)
        {
            int userid = Int32.Parse(txtuserid.Text.ToString());
            Users employeesearched = SearchEmployeebyId(userid);
            txtName.Text = employeesearched.EmployeeName;
            txtLoginId.Text = employeesearched.LoginId.ToString();
            txtpswd.Text = employeesearched.Password.ToString();
            txtManageUserId.Text = employeesearched.ManagerUserId.ToString();
            CmbUserid.Text = employeesearched.UserTypeId.ToString();

        }
        private  Users SearchEmployeebyId(int employeeid)
        {
            Users Searchedemployeeid = new Users();
            try
            {
                AdminBal searchemp = new AdminBal();
                    
                Searchedemployeeid = searchemp.searchEmployeeBL(employeeid);
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return Searchedemployeeid;
        }

        private void delemployee_Click(object sender, RoutedEventArgs e)
        {
           
            int employeeid = Int32.Parse(txtuserid.Text.ToString());
            DeleteEmployee(employeeid);

        }
        private void DeleteEmployee(int employeeid)
        {
            try
            {
                AdminBal delemp = new AdminBal();
                bool employeedeleted = delemp.DelEmployeeBAL(employeeid);
                if (employeedeleted)
                    MessageBox.Show("employee Deleted successfully");
                else
                    MessageBox.Show("employee not Deleted");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }


            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }


        }

        private void hladminpowers_Click(object sender, RoutedEventArgs e)
        {
            AdminPowers adp = new AdminPowers();
            adp.Show();
            this.Close();
        }

        private void resetemployee_Click(object sender, RoutedEventArgs e)
        {
            txtLoginId.Text = "";
            txtManageUserId.Text = "";
            txtName.Text = "";
            txtpswd.Text = "";
            txtuserid.Text = "";
            
        }
    }
}

    