﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETBAException;
using ETBA_BAL;
using ETBA_Entities;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for TravelAgentStatus.xaml
    /// </summary>
    public partial class TravelAgentStatus : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection Connection = new SqlConnection();

        public TravelAgentStatus()
        {
            InitializeComponent();
        }
        
        public void dispdetails()
        {
            SqlConnection connection = new SqlConnection();
            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();
                SqlCommand Command = new SqlCommand();
                Command.Connection = connection;
                string query = "ETBA.SP_StatusAccept";
                Command.CommandText = query;
                //SqlDataAdapter sda = new SqlDataAdapter(Command);

                SqlDataReader Reader = Command.ExecuteReader();
                DataTable Table = new DataTable();
                //sda.Fill(Table);
                Table.Load(Reader);
                dtdisplay.DataContext = Table;
                dtdisplay.Visibility = Visibility.Visible;
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Occured:" + Exception.Message);
            }
            catch (Exception Exception)
            {
                MessageBox.Show("Exception Occured:" + Exception.Message);
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }

            }



        }

        private void btnViewRequest_Click(object sender, RoutedEventArgs e)
        {
            dispdetails();
        }

        private void btnuptcktbkngstatus_Click(object sender, RoutedEventArgs e)
        {
            TravelRequests tr = new TravelRequests();
            tr.RequestId = Int32.Parse(txtRequestid.Text);
            tr.BookingStatus = Cmbstatus.Text;


            updatetravelstatu(tr);

        }
        private void updatetravelstatu(TravelRequests updatestatus)
            {
                SqlConnection connection = new SqlConnection();

                try
                {
                TravelAgentBal Tab = new TravelAgentBal();
                    bool statusupdated = Tab.conformingTicketBookingStatusBal(updatestatus);
                    if (statusupdated)
                    {
                        MessageBox.Show("Ticket Status Updated  Successfully");

                    dispdetails();
                    }
                    else
                        MessageBox.Show("Details not updated");
                }
                catch (ETBAException.ETBAException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    if (connection.State == System.Data.ConnectionState.Open)
                    {

                        connection.Close();

                    }

                }


            }

        }
    }
