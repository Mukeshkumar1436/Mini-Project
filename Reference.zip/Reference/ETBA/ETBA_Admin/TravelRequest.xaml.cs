﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETBAException;
using ETBA_BAL;
using ETBA_Entities;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for TravelRequest.xaml
    /// </summary>
    public partial class TravelRequest : Window
    {
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();
        SqlCommand cmd;
        int employeeid;
       
        public TravelRequest()
        {
            InitializeComponent();
        }
        public TravelRequest(int _employeeid)
        {
            InitializeComponent();
            employeeid = _employeeid;
           
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            dispdetails();
           
            connection.ConnectionString = ConnectionString;
            connection.Open();
            cmd = new SqlCommand("select ident_current('ETBA.RaiseTravelRequest') + ident_incr('ETBA.RaiseTravelRequest')", connection);
            try
            {
                //connection.Open();
                object nxId = cmd.ExecuteScalar();
                txtrequestid.Text = nxId.ToString();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
          finally
            {
                connection.Close();
            }

        }
        public void dispdetails()
        {
            try
            {
                connection.ConnectionString = ConnectionString;
                SqlCommand command = new SqlCommand();
                connection.Open();
                command.Connection = connection;
                string query = "[ETBA].[PutDetails1]";

                command.CommandType =System.Data.CommandType.StoredProcedure;
                command.CommandText = query;
                command.Parameters.AddWithValue("@Employeeid",employeeid);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                       txtempname.Text = reader[0].ToString();
                        txtmanagerusrid.Text = reader[1].ToString();
                        txtempid.Text = reader[2].ToString();
                       
                    }
                }
                else
                {
                    MessageBox.Show("no recored found");
                }
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {

                connection.Close();
            }

        }

        private void btnrequest_Click(object sender, RoutedEventArgs e)
        {
           
        
            try {

                TravelRequests tr = new TravelRequests()
                {
                    EmployeeId = Int32.Parse(txtempid.Text),
                    EmployeeName = txtempname.Text,
                    FromLocation = txtfrmlocation.Text,
                    ToLocation = txtToloaction.Text,
                    NumberofDays = Int32.Parse(txtNoofdays.Text),
                    TravelPurpose = txttrvlpurpose.Text,
                    ManagerId = Int32.Parse(txtmanagerusrid.Text),
                    RequestDate = DateTime.Parse(txtdatepicker.Text),
                    CurrentStatus = txtcturrentstatus.Text,
                    BookingStatus = txtbkngstatus.Text
            };
       
            
                EmployeeBAL empbal = new EmployeeBAL();
                bool requestraised = empbal.EmployeeRaiseTravelRequestBAl(tr);
                if (requestraised)
                {
                    MessageBox.Show("request raised Successfully");

                }
                else
                    MessageBox.Show("request  not raised Successfully");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
