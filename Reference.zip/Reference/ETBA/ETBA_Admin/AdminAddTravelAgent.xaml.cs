﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETBA_Entities;
using ETBA_BAL;
using ETBAException;
using System.Configuration;
using System.Data.SqlClient;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for AdminAddTravelAgent.xaml
    /// </summary>
    public partial class AdminAddTravelAgent : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        SqlCommand SqlCommand;
        public AdminAddTravelAgent()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            TravelAgent ta = new TravelAgent();
            ta.Name = txtname.Text;
            ta.Password = txtpswd.Password.ToString();
            ta.AgencyName = txtagencyname.Text;
            AddTravelAgent(ta);
        }
        private static void AddTravelAgent(TravelAgent addtravelagent)
        {
            try
            {
                AdminBal addtravelAgent = new AdminBal();
                bool TravelAgentadded = addtravelAgent.AddTravelAgentBL(addtravelagent);
                if (TravelAgentadded)
                {
                    MessageBox.Show("TravelAgent added Successfully");

                }
                else
                    MessageBox.Show("TravelAgent not added");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection.ConnectionString = ConnectionString;
            SqlCommand = new SqlCommand("select ident_current('ETBA.travelagentdetails') + ident_incr('ETBA.travelagentdetails')", SqlConnection);
            try
            {
                SqlConnection.Open();
                object nxId = SqlCommand.ExecuteScalar();
                txttravelid.Text = nxId.ToString();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlConnection.Close();

            }

        }

        private void travelagentsearch_Click(object sender, RoutedEventArgs e)
        {
            int trid = Int32.Parse(txttravelid.Text.ToString());
            TravelAgent travelidsearched = SearchTravelid(trid);

            txtname.Text = travelidsearched.Name;
            txtpswd.Password = travelidsearched.Password;
            txtagencyname.Text = travelidsearched.AgencyName;

        }
        private static TravelAgent SearchTravelid(int travelid)
        {
            TravelAgent Searchedtravelid = new TravelAgent();
            try
            {
                AdminBal searchtragent = new AdminBal();
                Searchedtravelid = searchtragent.searchtravelagentBL(travelid);
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return Searchedtravelid;
        }




        private void travelagentup_Click(object sender, RoutedEventArgs e)
        {
            TravelAgent type = new TravelAgent();
            type.TravelID = Int32.Parse(txttravelid.Text);
            type.Name = txtname.Text;
            type.Password = txtpswd.Password.ToString();
            type.AgencyName = txtagencyname.Text;
            EditTravelAgent(type);
        }

        private static void EditTravelAgent(TravelAgent edittravelagent)
        {

            try
            {
                AdminBal edittragent = new AdminBal();
                bool travelagentedited = edittragent.UpdateTravelAgentbal(edittravelagent);
                if (travelagentedited)
                {
                    MessageBox.Show("travelagent edited Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void hladminpowers_Click(object sender, RoutedEventArgs e)
        {
            AdminPowers adp = new AdminPowers();
            adp.Show();
            this.Close();

        }

        private void travelagentreset_Click(object sender, RoutedEventArgs e)
        {
            txttravelid.Text = "";
            txtpswd.Password = "";
            txtname.Text = "";
            txtagencyname.Text = "";
        }
    }
}

