﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETBAException;
using ETBA_BAL;
using ETBA_Entities;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for CancelTravelRequest.xaml
    /// </summary>
    public partial class CancelTravelRequest : Window
    {
        string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection();

        int employeeid;
        public CancelTravelRequest()
        {
            InitializeComponent();
        }
        public CancelTravelRequest(int _employeeid)
        {
            InitializeComponent();
            employeeid = _employeeid;
        }
        public void dispdetails()
        {
            try
            {
                connection.ConnectionString = ConnectionString;
                SqlCommand command = new SqlCommand();
                connection.Open();
                command.Connection = connection;
                string query = "[ETBA].[PutDetails1]";

                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandText = query;
                command.Parameters.AddWithValue("@Employeeid", employeeid);
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                        txtepname.Text = reader[0].ToString();
                        txtassimanaerid.Text = reader[1].ToString();
                        txtempid.Text = reader[2].ToString();



                    }
                }
                else
                {
                    MessageBox.Show("no recored found");
                }
            }
            catch (SqlException Exception)
            {
                MessageBox.Show("Exception Ocurred" + Exception.Message);
            }
            finally
            {

                connection.Close();
            }

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dispdetails();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int requestid = Int32.Parse(txtrequestid.Text.ToString());
            CancelTravelRequestbyRequestid(requestid);
        }

        private void CancelTravelRequestbyRequestid(int RequestId)
        {
            try
            {
                EmployeeBAL empbal = new EmployeeBAL();
                bool employeedeleted = empbal.CancelTravelRequestBal(RequestId);
                if (employeedeleted)
                    MessageBox.Show("Travel Request Cancelled successfully");
                else
                    MessageBox.Show("TravelRequest not cancelled");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }


            catch (Exception ex)
            {
                MessageBox.Show("Exception Ocurred." + ex.Message);
            }

        }


    }
}