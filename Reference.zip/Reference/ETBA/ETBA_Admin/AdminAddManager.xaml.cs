﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ETBA_Entities;
using ETBA_BAL;
using ETBAException;
using System.Data.SqlClient;
using System.Configuration;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for AdminAddManager.xaml
    /// </summary>
    public partial class AdminAddManager : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        SqlCommand SqlCommand;
        public AdminAddManager()
        {
            InitializeComponent();
        }

        private void Addmanager_Click(object sender, RoutedEventArgs e)
        {
            Manager manager = new Manager();
     
            manager.ManagerName = txtmanagername.Text;
            AddManager(manager);


        }
        private static void AddManager(Manager addmanager)
        {
            try
            {
                AdminBal addmanage = new AdminBal();
                bool employeeadded = addmanage.AddManagerBL(addmanager);
                if (employeeadded)
                {
                    MessageBox.Show("Manager added Successfully");

                }
                else
                    MessageBox.Show("Manager Not added");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void hladminpowers_Click(object sender, RoutedEventArgs e)
        {
            AdminPowers adp = new AdminPowers();
            adp.Show();
            this.Close();
        }



        private void btnsearch_Click(object sender, RoutedEventArgs e)
        {
            int manageruserid = Int32.Parse(txtmanagerid.Text.ToString());
            Manager Managersearched = SearchManagerbyId(manageruserid);
            txtmanagerid.Text = Managersearched.ManagerId.ToString();
            txtmanagername.Text = Managersearched.ManagerName.ToString();


        }

        private static Manager SearchManagerbyId(int managerid)
        {
            Manager SearchedManagerid = new Manager();
            try
            {
                AdminBal searchmanager = new AdminBal();
                SearchedManagerid = searchmanager.searchManagerBL(managerid);
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }
            return SearchedManagerid;
        }


       private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
        Manager type = new Manager();
        type.ManagerId = Int32.Parse(txtmanagerid.Text);
        type.ManagerName = txtmanagername.Text;
            UpdateManager(type);
    }
        private static void UpdateManager(Manager editmanager)
        {

            try
            {
                AdminBal upmanager = new AdminBal();
                bool manageredited = upmanager.UpdateManagerBal(editmanager);
                if (manageredited)
                {
                    MessageBox.Show("Manager edited Successfully");

                }
                else
                    MessageBox.Show("Details not updated");
            }
            catch (ETBAException.ETBAException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
   
   
    private void btnreset_Click(object sender, RoutedEventArgs e)
        {
            txtmanagerid.Text = "";
            txtmanagername.Text = "";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection.ConnectionString = ConnectionString;
            SqlCommand = new SqlCommand("select ident_current('[ETBA].[manager]') + ident_incr('[ETBA].[manager]')", SqlConnection);
            try
            {
                SqlConnection.Open();
                object nxId = SqlCommand.ExecuteScalar();
                txtmanagerid.Text = nxId.ToString();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SqlConnection.Close();

            }
        }
    }
}
