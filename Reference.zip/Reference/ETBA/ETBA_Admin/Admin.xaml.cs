﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ETBAException;
using ETBA_BAL;
using ETBA_Entities;


namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        //public string adminid; string pswd;
        //AddEmployeeBal adb = new AddEmployeeBal();

        public Admin()
        {
          
            InitializeComponent();
        }

       

            //string constring = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            //SqlConnection connection = new SqlConnection(constring);
            //try
            //{
            //    Admin admn = new Admin();
            //    adminid = textBoxUserId.Text;
            //    pswd = passwordBox1.Password.ToString();
            //    admn = adb.loginbal(adminid, pswd);
            //    if (!string.IsNullOrEmpty(admn.pswd))
            //    {

            //        MessageBox.Show("Login Successful");
            //        AdminPowers ap = new AdminPowers();
            //        ap.Show();

            //    }
            //    else
            //    {
            //        MessageBox.Show("Invalid Username or Password");
            //    }
            //}
            //catch (SqlException)
            //{
            //    throw;
            //}
            //finally
            //{
            //    connection.Close();
            //}


       

        private void hypforget_Click(object sender, RoutedEventArgs e)
        {
            ForgotPasswordpage fgp = new ForgotPasswordpage();
            this.Content = fgp;

        }

        private void btncancel_Click(object sender, RoutedEventArgs e)
        {
            textBoxUserId.Text = string.Empty;
            passwordBox1.Clear();

        }

        private void adminpowers_Click(object sender, RoutedEventArgs e)
        {
            AdminPowers ap = new AdminPowers();
            ap.Show();
        
        }

        private void gobacktomainwindow_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void btnlogin_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                SqlConnection.ConnectionString = ConnectionString;

                string query = "select Adminid,Password from [ETBA].[Admin] where Adminid ='" + textBoxUserId.Text + "' and Password='" + passwordBox1.Password.ToString() + "' ";
                SqlCommand cmd = new SqlCommand(query, SqlConnection);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {

                    if (textBoxUserId.Text.Trim() == string.Empty)
                    {
                        MessageBox.Show("userid cannot be blank");
                    }
                    else if (passwordBox1.Password.ToString().Trim() == string.Empty)
                    {
                        MessageBox.Show("password box cannot be empty");

                    }
                    MessageBox.Show("Login Successful");
                    AdminPowers admin = new AdminPowers();
                    admin.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password");
                }

            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                SqlConnection.Close();
            }
        }
    }
}
