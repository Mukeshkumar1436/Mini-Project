﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ETBA_Admin
{
    /// <summary>
    /// Interaction logic for ManagerLogin.xaml
    /// </summary>
    public partial class ManagerLogin : Window
    {
        static string ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection SqlConnection = new SqlConnection();
        public ManagerLogin()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SqlConnection.ConnectionString = ConnectionString;

                string query = "select Managerid ,ManagerName from [ETBA].[manager] where Managerid='" + textBoxUserId.Text + "' and ManagerName='" + passwordBox1.Password.ToString() + "' ";
                SqlCommand cmd = new SqlCommand(query, SqlConnection);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {

                    if (textBoxUserId.Text.Trim() == string.Empty)
                    {
                        MessageBox.Show("Managerid cannot be blank");
                    }
                    else if (passwordBox1.Password.ToString().Trim() == string.Empty)
                    {
                        MessageBox.Show("managername cannot be empty");

                    }
                    MessageBox.Show("Login Successful");
                    RequestReceived reqrec = new RequestReceived();
                    reqrec.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password");
                }

            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                SqlConnection.Close();
            }
        }

        private void gobacktomainwindow_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
    }
}
