﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETBA_Entities
{
  public class TravelAgent
    {
        public int TravelID { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string AgencyName { get; set; }
    }
}
