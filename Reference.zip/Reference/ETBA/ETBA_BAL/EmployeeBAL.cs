﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETBA_Entities;
using ETBAException;
using ETBA_DAL;
using System.Text.RegularExpressions;

namespace ETBA_BAL
{
    public class EmployeeBAL
    {
        StringBuilder sb = new StringBuilder();

        private bool ValidateRequest(TravelRequests request)
        {
            bool isValidRequest = true;

            if (!Regex.Match(request.NumberofDays.ToString(), @"^[0-9]{1}$").Success)
            {
                isValidRequest = false;
                sb.Append(Environment.NewLine + "Days must be in between 0-9");
            }
            if (request.ToLocation.Equals(string.Empty))
            {
                isValidRequest = false;
                sb.Append("Tolocation cannot be blank " + Environment.NewLine);
            }
            if (request.TravelPurpose.Equals(string.Empty))
            {
                isValidRequest = false;
                sb.Append("travel purpose cannot be blank " + Environment.NewLine);
            }
            if (request.FromLocation == string.Empty)
            {
                isValidRequest = false;
                sb.Append(Environment.NewLine + "from location is Required");
            }
            if (request.RequestId.ToString() == string.Empty)
            {
                isValidRequest = false;
                sb.Append(Environment.NewLine + "requestid is required");
            }
           


            return isValidRequest;
        }

        public bool EmployeeRaiseTravelRequestBAl(TravelRequests RaiseRequest)
        {
            bool isRequestRaised = false;
            try
            {
                if (ValidateRequest(RaiseRequest))
                {
                    EmployeeDAL empdal = new EmployeeDAL();
                    isRequestRaised = empdal.EmployeeRaiseTravelRequestDAl(RaiseRequest);
                }
                else
                {
                    throw new ETBAException.ETBAException(sb.ToString());
                }

            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return isRequestRaised;
        }
        public TravelRequests checktravelstatusbal(int requestid)
        {
            TravelRequests checkstatus = null;
            try
            {

                  EmployeeDAL ckstatus = new EmployeeDAL();
                    checkstatus = ckstatus.travelRequestsstatusdal(requestid);
                
            }

            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return checkstatus;
        }

        public bool CancelTravelRequestBal(int Requestid)
        {
            bool isrequestcancelled = false;
            try
            {
               
                    EmployeeDAL empdal = new EmployeeDAL();
                    isrequestcancelled = empdal.CancelTravelRequest(Requestid);
                
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return isrequestcancelled;
        }


    }
}