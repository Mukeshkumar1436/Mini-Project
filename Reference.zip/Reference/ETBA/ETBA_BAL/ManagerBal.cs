﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETBAException;
using ETBA_DAL;
using ETBA_Entities;

namespace ETBA_BAL
{
  public class ManagerBal
    {
        public bool UpdateEmployeeTravelStatusBal(TravelRequests updateRequets)
        {
            bool isstatusupdated = false;
            try
            {

                ManagerDal md = new ManagerDal();
                isstatusupdated = md.UpdateEmployeeTravelStatusDal(updateRequets);

            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isstatusupdated;

        }
    }
}
