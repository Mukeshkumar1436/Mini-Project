﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ETBAException;
using ETBA_DAL;
using ETBA_Entities;
using System.Text.RegularExpressions;

namespace ETBA_BAL
{
 public class AdminBal
    {
        StringBuilder sb = new StringBuilder();
        private bool ValidateEmployee(Users newemployee)
        {
            bool isValidEmployee = true;


            if (!Regex.Match(newemployee.LoginId.ToString(), @"^[0-9]{4}$").Success)
            {
                isValidEmployee = false;
                sb.Append(Environment.NewLine + "LoginId should not have Alphabets and Special Characters");
            }
            if (newemployee.Password.Equals(string.Empty))
            {
                isValidEmployee = false;
                sb.Append("password cannot be blank " + Environment.NewLine);

            }
            if (!(Regex.IsMatch(newemployee.ManagerUserId.ToString(), @"^[0-9]{4}$")))
            {
                isValidEmployee = false;
                sb.Append(Environment.NewLine + "ManagerUserId should be in the range of 1-7 Numbers ");
            }
            //if (!(Regex.IsMatch(newemployee.UserTypeId.ToString(), @"^[1-3]{1}$")))
            //{
            //    isValidEmployee = false;
            //    sb.Append(Environment.NewLine + "UsertypeId should be in the range of 1-3 Numbers ");
            //}


            if (newemployee.EmployeeName == string.Empty)
            {
                isValidEmployee = false;
                sb.Append(Environment.NewLine + "Employee Name Required");
            }

            return isValidEmployee;
        }

        public bool AddEmployeeBL(Users addemp)
        {
            bool Personadded = false;
            try
            {
                if (ValidateEmployee(addemp))
                {
                    AdminDal addemployee = new AdminDal();
                    Personadded = addemployee.AddEmployeDal(addemp);
                }
                else
                {
                    throw new ETBAException.ETBAException(sb.ToString());
                }

            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Personadded;
        }
        public bool AddManagerBL(Manager addmanager)
        {
            bool Manageradded = false;
            try
            {
                AdminDal addmanag = new AdminDal();
                Manageradded = addmanag.AddManagerDal(addmanager);

            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Manageradded;
        }
        public bool AddTravelAgentBL(TravelAgent addTravelagent)
        {
            bool istravelagentadded = false;
            try
            {
                AdminDal addtravelagent = new AdminDal();
                istravelagentadded = addtravelagent.AddTravelAgentDal(addTravelagent);

            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return istravelagentadded;
        }
        public bool UpdateEmployeeBal(Users editemp)
        {
            bool employeeedited = false;
            try
            {
                if (ValidateEmployee(editemp))
                {
                    AdminDal upemp = new AdminDal();
                    employeeedited = upemp.EditEmployee(editemp);
                }
            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeedited;

        }
        public Users searchEmployeeBL(int userid)
        {
            Users searchemployee = null;
            try
            {

                AdminDal searchemp = new AdminDal();
                searchemployee = searchemp.searchEmployeeDal(userid);

            }

            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return searchemployee;

        }
        public Manager searchManagerBL(int manauserid)
        {
            Manager searchmanager = null;
            try
            {

                AdminDal serachmanager = new AdminDal();
                searchmanager = serachmanager.searchManagerDal(manauserid);

            }

            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return searchmanager;

        }
        public bool UpdateManagerBal(Manager upmanager)
        {
            bool Manageredited = false;
            try
            {

                AdminDal updatemanager = new AdminDal();
                Manageredited = updatemanager.UpdateManager(upmanager);

            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Manageredited;

        }

        public TravelAgent searchtravelagentBL(int travelid)
        {
            TravelAgent searchTravelid = null;
            try
            {
                AdminDal searchtravelagent = new AdminDal();
                searchTravelid = searchtravelagent.searchTravelAgentDal(travelid);
            }

            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            return searchTravelid;

        }
        public bool UpdateTravelAgentbal(TravelAgent edittravelagent)
        {
            bool Travelagentedited = false;
            try
            {

                AdminDal updatetravelagent = new AdminDal();
                Travelagentedited = updatetravelagent.EditTravelAgentDal(edittravelagent);

            }
            catch (ETBAException.ETBAException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Travelagentedited;

        }

        public bool DelEmployeeBAL(int userid)
        {
            bool employeedeleted = false;
            try
            {
                AdminDal delemp = new AdminDal();
                employeedeleted = delemp.DeleteEmployeeDAL(userid);
            }
            catch (ETBAException.ETBAException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeedeleted;
        }

    }
}
