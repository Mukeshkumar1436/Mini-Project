﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeTravelRequestEntity;
using EmployeeException;
using TravelRequestDAL;

namespace TravelRequestBAL
{
   
        //public static bool ExpenseRequest_BAL(TravelRequest tr)
        //{
        //    bool reqAdded = false;
        //    TReq_DAL req_DAL = new TReq_DAL();

        //    reqAdded = req_DAL.ExpenseRequest_DAL(tr);

        //    if (reqAdded)
        //    {
        //        reqAdded = true;
        //    }
        //    return reqAdded;
        //}

      

       


        }

