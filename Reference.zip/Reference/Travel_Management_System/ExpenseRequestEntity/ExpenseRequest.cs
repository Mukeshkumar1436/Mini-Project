﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpenseRequestEntity
{
    public class ExpenseRequest
    {
        public int Employee_ID { get; set; }
        public int ExpenseReport_ID { get; set; }
        public string Expense_Type { get; set; }
        public DateTime Expense_Date { get; set; }
        public int Amount_Paid { get; set; }
        public string Payment_Type { get; set; }
        public int MR_Number { get; set; }
        public int Reimbursement_Account_no { get; set; }
        public string Expense_Status { get; set; }

    }
}
