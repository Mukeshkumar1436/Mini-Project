﻿using EmployeeEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpenseRequestEntity;
using EmployeeBAL;
using EmployeeException;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for ExpenseRequestUpdatePage.xaml
    /// </summary>
    public partial class ExpenseRequestUpdatePage : Page
    {
        int empid;
        public ExpenseRequestUpdatePage()
        {
            InitializeComponent();
        }
        public ExpenseRequestUpdatePage(Emp_Entity val) : this()
        {
            empid = val.Employee_ID;
            this.Loaded += new RoutedEventHandler(Page_Loaded);
        }

        public void Loadgrid()
        {
           ExpenseBAL exprequpd  = new ExpenseBAL();
            DataSet dataset = new DataSet();
            dataset = exprequpd.ExpenseRequestUpdate_LoadGrid_BAL(empid);
            dgExpenseReqUpdate.DataContext = dataset.Tables[0];
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            txtEmpID.Text = empid.ToString();
           
            Loadgrid();
        }

        private void dgExpenseReqUpdate_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dg = (DataGrid)sender;
            DataRowView row_selected = dg.SelectedItem as DataRowView;

            if (row_selected != null)
            {
                if (row_selected[8].ToString() == "Pending")
                {
                    txtExpenseReportId.Text = row_selected[1].ToString();
                    txtEmpID.Text = row_selected[0].ToString();
                    txtMR_no.Text = row_selected[6].ToString();
                    txtExpenseDate.Text =Convert.ToDateTime(row_selected[3]).ToString();
                    txtAmountPaid.Text = row_selected[4].ToString();
                    txtPaymentType.Text = row_selected[5].ToString();
                    txtAccountNumber.Text = row_selected[7].ToString();
                }
                else
                {
                    MessageBox.Show("Sorry!! You cannot Modify your request now.Because it is Already " + row_selected[8].ToString());
                }
            }
        }

        private void btnRequestUpdate_Click(object sender, RoutedEventArgs e)
        {
            if(String.IsNullOrEmpty(txtAccountNumber.Text) || String.IsNullOrEmpty(txtAmountPaid.Text) || String.IsNullOrEmpty(txtEmpID.Text) || String.IsNullOrEmpty(txtExpenseDate.Text) || String.IsNullOrEmpty(txtExpenseReportId.Text) || String.IsNullOrEmpty(txtMR_no.Text) || String.IsNullOrEmpty(txtPaymentType.Text) || String.IsNullOrEmpty(cbExpenseType.Text)  )
            {
                MessageBox.Show("Fields Cannot be Empty.");
            }
            if (!String.IsNullOrEmpty(txtEmpID.Text))
            {
                for (int i = 0; i < txtEmpID.Text.Length; i++)
                {
                    if (!char.IsNumber(txtEmpID.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Employee ID.");
                        i = txtEmpID.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtMR_no.Text))
            {
                for (int i = 0; i < txtMR_no.Text.Length; i++)
                {
                    if (!char.IsNumber(txtMR_no.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in MR Number.");
                        i = txtMR_no.Text.Length + 1;
                    }
                }
            }

            if (!String.IsNullOrEmpty(txtAmountPaid.Text))
            {
                for (int i = 0; i < txtAmountPaid.Text.Length; i++)
                {
                    if (!char.IsNumber(txtAmountPaid.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Amount paid.");
                        i = txtAmountPaid.Text.Length + 1;
                    }
                }
            }

            if (!String.IsNullOrEmpty(txtAccountNumber.Text))
            {
                for (int i = 0; i < txtAccountNumber.Text.Length; i++)
                {
                    if (!char.IsNumber(txtAccountNumber.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Reimbursement Account Number.");
                        i = txtAccountNumber.Text.Length + 1;
                    }
                }
            }

            if (!String.IsNullOrEmpty(txtPaymentType.Text))
            {
                for (int i = 0; i < txtPaymentType.Text.Length; i++)
                {
                    if (!char.IsLetter(txtPaymentType.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Payment type.");
                        i = txtPaymentType.Text.Length + 1;
                    }
                }
            }

            else if (int.Parse(txtAmountPaid.Text) <= 0)
            {
                MessageBox.Show("AMount Cannot be 0 or less.");
            }
            else if (int.Parse(txtEmpID.Text) <= 0)
            {
                MessageBox.Show("Employee ID Cannot be 0 or less.");
            }
            else if (int.Parse(txtExpenseReportId.Text) <= 0)
            {
                MessageBox.Show("Expense Id Cannot be 0 or less.");
            }
            else if (int.Parse(txtMR_no.Text) <= 0)
            {
                MessageBox.Show("MR number Cannot be 0 or less.");
            }
            else if (int.Parse(txtAccountNumber.Text) <= 0)
            {
                MessageBox.Show("Account number Cannot be 0 or less.");
            }
            else
            {
                ExpenseRequest tr = new ExpenseRequest();
                try
                {
                    tr.MR_Number = int.Parse(txtMR_no.Text);
                    tr.Employee_ID = empid;
                    tr.Expense_Date = Convert.ToDateTime(txtExpenseDate.Text);
                    tr.ExpenseReport_ID = int.Parse(txtExpenseReportId.Text);
                    tr.Amount_Paid = int.Parse(txtAmountPaid.Text);
                    tr.Expense_Type = cbExpenseType.Text;
                    tr.Reimbursement_Account_no = int.Parse(txtAccountNumber.Text);
                    tr.Payment_Type = txtPaymentType.Text;
                    tr.Expense_Status = "Pending";

                    bool requestAdded = ExpenseBAL.UpdateTravelRequest_BAL(tr);

                    if (requestAdded)
                    {
                        MessageBox.Show("Updated Successfully");
                    }
                }
                catch (Emp_Exception ex)
                {
                    MessageBox.Show(ex.Message + "Expense Request");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "Expense Request");
                }
            }
            
        }
    }
}
