﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeBAL;
using EmployeeTravelRequestEntity;
using EmployeeException;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for AdminRequestsAprovalPage.xaml
    /// </summary>
    public partial class AdminRequestsAprovalPage : Page
    {
     
        public AdminRequestsAprovalPage()
        {
            InitializeComponent();
        }

        public void LoadGrid()
        {
                TReq_BAL treq = new TReq_BAL();
                DataSet dataset = treq.LoadGrid_PendingTravelDetails_BAL();
                dgTravelReq.DataContext = dataset.Tables[0]; 
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrid();
        }

        private void btnStatusUpdate_Click(object sender, RoutedEventArgs e)
        {

            if (String.IsNullOrEmpty(cbRequestStatus.Text))
            {
                MessageBox.Show("Please Change the Status of request.");
            }
            else
            {
                TReq_BAL reqStatus = new TReq_BAL();
                int MR_number = Int32.Parse(txtMR_no.Text);
                string statusUpdated = "";

                if (cbRequestStatus.Text == "Approve")
                {
                    statusUpdated = "Approved";
                    reqStatus.RequestStatus_BAL(MR_number, statusUpdated);

                }
                else if (cbRequestStatus.Text == "Reject")
                {
                    statusUpdated = "Rejected";
                    reqStatus.RequestStatus_BAL(MR_number, statusUpdated);
                }
                else
                {
                    statusUpdated = "Pending";
                    reqStatus.RequestStatus_BAL(MR_number, statusUpdated);
                }
                MessageBox.Show("Request " + statusUpdated);
                ClearAll();
                LoadGrid();
            }
         

        }

        //private void btnSearch_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        int MR_no = int.Parse(txtMR_no.Text);
        //        TravelRequest searchedTR = new TravelRequest();
        //        TReq_BAL req = new TReq_BAL();
        //        searchedTR = req.SearchTravelRequest_BAL(MR_no);

        //        txtEmpID.Text = searchedTR.Employee_ID.ToString();
        //        txtMR_no.Text = searchedTR.MR_Number.ToString();
        //        txtApplyDate.Text = Convert.ToDateTime(searchedTR.Apply_Date).ToString();
        //        txtFromCity.Text = searchedTR.From_city.ToString();
        //        txtToCity.Text = searchedTR.To_City.ToString();
        //        txtTravelDate.Text = Convert.ToDateTime(searchedTR.Travel_Date).ToString();
        //        txtTravelMode.Text = searchedTR.Travel_Mode.ToString();
        //        txtReason.Text = searchedTR.Reason_For_Travel.ToString();
        //    }
        //    catch (Exception)
        //    {

        //        MessageBox.Show("Unable to search the record.");
        //    }

        //}

        private void ClearAll()
        {
            txtEmpID.Text = null;
            txtFromCity.Text = null;
            txtMR_no.Text = null;
            txtReason.Text = null;
            txtTravelDate.Text = null;
            txtTravelMode.Text = null;
            txtApplyDate.Text = null;
            cbRequestStatus.Text = null;
            txtToCity.Text = null;
        }

        private void dgTravelReq_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                DataGrid dataGrid = (DataGrid)sender;
                DataRowView row_selected = dataGrid.SelectedItem as DataRowView;

                if (row_selected != null)
                {
                    txtEmpID.Text = row_selected[1].ToString();
                    txtMR_no.Text = row_selected[0].ToString();
                    txtApplyDate.Text = Convert.ToDateTime(row_selected[2]).ToString();
                    txtFromCity.Text = row_selected[6].ToString();
                    txtToCity.Text = row_selected[7].ToString();
                    txtTravelDate.Text = Convert.ToDateTime(row_selected[4]).ToString();
                    txtTravelMode.Text = row_selected[5].ToString();
                    txtReason.Text = row_selected[3].ToString();
                }
            }
            catch (Exception)
            {
                throw;
            }
          
        }
    }


    
}
