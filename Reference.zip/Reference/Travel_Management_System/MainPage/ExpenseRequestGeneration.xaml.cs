﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpenseRequestEntity;
using EmployeeException;
using System.Configuration;
using System.Data.SqlClient;
using EmployeeEntity;
using EmployeeBAL;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for ExpenseRequest.xaml
    /// </summary>
    public partial class ExpenseRequestGeneration : Page
    {
        //string User;
        int empid, ReimbNo;
        Emp_Entity empnew = new Emp_Entity();
        static string Constring = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(Constring);
        SqlCommand Command = new SqlCommand();

        public ExpenseRequestGeneration()
        {
            InitializeComponent();
        }

        public ExpenseRequestGeneration(Emp_Entity val) : this()
        {
            empid = val.Employee_ID;
            ReimbNo = val.Reimburse_Account_No;
            this.Loaded += new RoutedEventHandler(Page_Loaded);
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            AdminPage main = new AdminPage();
            this.Content = main;
        }

        private void btnGenerateExp_Click(object sender, RoutedEventArgs e)
        {
            if(String.IsNullOrEmpty(txtAmountPaid.Text) || String.IsNullOrEmpty(txtEmpID.Text) || String.IsNullOrEmpty(txtExpenseReportID.Text) || String.IsNullOrEmpty(txtMRNumber.Text) || String.IsNullOrEmpty(txtPaymentType.Text) || String.IsNullOrEmpty(txtReimbAccNo.Text) || String.IsNullOrEmpty(dpExpenseDate.Text) || String.IsNullOrEmpty(cbExpenseType.Text) )
            {
                MessageBox.Show("Fields Cannot be Empty.");
            }

            if (!String.IsNullOrEmpty(txtEmpID.Text))
            {
                for (int i = 0; i < txtEmpID.Text.Length; i++)
                {
                    if (!char.IsNumber(txtEmpID.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Employee ID.");
                        i = txtEmpID.Text.Length + 1;
                    }
                }
            }
            if (!String.IsNullOrEmpty(txtMRNumber.Text))
            {
                for (int i = 0; i < txtMRNumber.Text.Length; i++)
                {
                    if (!char.IsNumber(txtMRNumber.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in MR Number.");
                        i = txtMRNumber.Text.Length + 1;
                    }
                }
            }

            if (!String.IsNullOrEmpty(txtAmountPaid.Text))
            {
                for (int i = 0; i < txtAmountPaid.Text.Length; i++)
                {
                    if (!char.IsNumber(txtAmountPaid.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Amount paid.");
                        i = txtAmountPaid.Text.Length + 1;
                    }
                }
            }

            if (!String.IsNullOrEmpty(txtReimbAccNo.Text))
            {
                for (int i = 0; i < txtReimbAccNo.Text.Length; i++)
                {
                    if (!char.IsNumber(txtReimbAccNo.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Reimbursement Account Number.");
                        i = txtReimbAccNo.Text.Length + 1;
                    }
                }
            }

            if (!String.IsNullOrEmpty(txtPaymentType.Text))
            {
                for (int i = 0; i < txtPaymentType.Text.Length; i++)
                {
                    if (!char.IsLetter(txtPaymentType.Text[i]))
                    {
                        MessageBox.Show("Incorrect Type of value in Payment type.");
                        i = txtPaymentType.Text.Length + 1;
                    }
                }
            }
            
            else if(int.Parse(txtReimbAccNo.Text) <= 0)
            {
                MessageBox.Show("Reimbursement Number Cannot be 0 or less.");
            }
            else if (int.Parse(txtAmountPaid.Text) <= 0)
            {
                MessageBox.Show("Amount Cannot be Negative.");
            }
            else if (int.Parse(txtEmpID.Text) <= 0)
            {
                MessageBox.Show("Employee ID Cannot be Negative.");
            }
            else if (int.Parse(txtExpenseReportID.Text) <= 0)
            {
                MessageBox.Show("Report ID Cannot be Negative.");
            }
            else if (int.Parse(txtMRNumber.Text) <= 0)
            {
                MessageBox.Show("MR Number Cannot be Negative.");
            }
            else
            {
                try
                {
                    ExpenseRequest er = new ExpenseRequest
                    {
                        ExpenseReport_ID = int.Parse(txtExpenseReportID.Text),
                        Amount_Paid = int.Parse(txtAmountPaid.Text),
                        Employee_ID = int.Parse(txtEmpID.Text),
                        Expense_Date = Convert.ToDateTime(dpExpenseDate.ToString()),
                        Expense_Status = "Pending",
                        Expense_Type = txtPaymentType.Text,
                        MR_Number = int.Parse(txtMRNumber.Text),
                        Payment_Type = txtPaymentType.Text,
                        Reimbursement_Account_no = int.Parse(txtReimbAccNo.Text)
                    };

                    ExpenseBAL expense = new ExpenseBAL();

                    bool requestAdded = expense.ExpenseRequestGen_BAL(er);

                    if (requestAdded)
                    {
                        MessageBox.Show("Expense Request Added Sccessfully.Your MR Number for this Expense Request is " + er.MR_Number);
                    }

                }
                catch (Emp_Exception)
                {
                    MessageBox.Show("All fields are mandstory");
                }
                catch (Exception)
                {
                    MessageBox.Show("All fields are Mandatory");
                }
            }
               
            
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ExpenseBAL expense = new ExpenseBAL();
            Random random = new Random();
            int x = random.Next(1000,10000);
            txtEmpID.Text =empid.ToString();
            txtReimbAccNo.Text = ReimbNo.ToString();
            txtMRNumber.Text = x.ToString();
            txtExpenseReportID.Text = expense.AutoIncrExpenseId_BAL().ToString();
            
        }
    }
}
