﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ExpenseRequestEntity;
using EmployeeBAL;
using EmployeeException;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for ExpenseRequestApprovalPage.xaml
    /// </summary>
    public partial class ExpenseRequestApprovalPage : Page
    {
    

        public ExpenseRequestApprovalPage()
        {
            InitializeComponent();
        }

        public void LoadGrid_PendingExpenseDetails()
        {
            try
            {
                ExpenseBAL emp = new ExpenseBAL();
                DataSet dataset = emp.LoadGrid_PendingExpenseDetails_BAL();
                dgExpenseReq.DataContext = dataset.Tables[0];
            }
            catch (Emp_Exception)
            {
                MessageBox.Show("Cannot Load the Grid.");
            }
            catch (Exception Execption)
            {
                MessageBox.Show(Execption.Message);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            LoadGrid_PendingExpenseDetails();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtMR_no.Text))
            {
                MessageBox.Show("MR number Cannot be blank.");
            }
            if (int.Parse(txtMR_no.Text) <= 0)
            {
                MessageBox.Show("MR number cannot be 0 or less.");
            }
            else
            {
                try
                {
                    int MR_no = int.Parse(txtMR_no.Text);
                    ExpenseRequest searchedTR = new ExpenseRequest();
                    ExpenseBAL req = new ExpenseBAL();
                    searchedTR = req.SearchExpenseRequest_BAL(MR_no);
                    if (searchedTR != null)
                    {
                        txtEmpID.Text = searchedTR.Employee_ID.ToString();
                        txtMR_no.Text = searchedTR.MR_Number.ToString();
                        txtExpenseDate.Text = Convert.ToDateTime(searchedTR.Expense_Date).ToString();
                        txtExpenseType.Text = searchedTR.Expense_Type.ToString();
                        txtPaymentType.Text = searchedTR.Payment_Type.ToString();
                        txtAccNo.Text = searchedTR.Reimbursement_Account_no.ToString();
                        txtAmountPaid.Text = searchedTR.Amount_Paid.ToString();
                        txtExpenseReportID.Text = searchedTR.ExpenseReport_ID.ToString();
                    }
                    else
                    {
                        MessageBox.Show("No record found");
                    }
                }
                catch (Emp_Exception ex)
                {
                    MessageBox.Show(ex.Message+" Cannot search");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message+" Cannot search");
                }

            }
        }

        private void btnStatusUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (String.IsNullOrEmpty(txtMR_no.Text))
            {
                MessageBox.Show("MR number Cannot be blank.");
            }
            if (int.Parse(txtMR_no.Text) <= 0)
            {
                MessageBox.Show("MR number cannot be 0 or less.");
            }
           
            if (String.IsNullOrEmpty(cbExpenseStatus.Text))
            {
                MessageBox.Show("Please Select Status to update.");
            }
            else
            {
                try
                {
                    ExpenseBAL reqStatus = new ExpenseBAL();
                    int MR_number = Int32.Parse(txtMR_no.Text);
                    string statusUpdated = "";

                    if (cbExpenseStatus.Text == "Approve")
                    {
                        statusUpdated = "Approved";
                        reqStatus.ExpenseStatus_BAL(MR_number, statusUpdated);

                    }
                    else if (cbExpenseStatus.Text == "Reject")
                    {
                        statusUpdated = "Rejected";
                        reqStatus.ExpenseStatus_BAL(MR_number, statusUpdated);

                    }
                    else
                    {
                        statusUpdated = "Pending";
                        reqStatus.ExpenseStatus_BAL(MR_number, statusUpdated);
                    }
                    MessageBox.Show("Request " + statusUpdated);
                    LoadGrid_PendingExpenseDetails();
                }
                catch (Emp_Exception ex)
                {
                    MessageBox.Show(ex.Message + "Cannot update.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message + "Cannot Update.");
                }

            }

        }

        private void dgExpenseReq_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                DataGrid dg = (DataGrid)sender;
                DataRowView row_selected = dg.SelectedItem as DataRowView;

                if (row_selected != null)
                {
                    txtEmpID.Text = row_selected[0].ToString();
                    txtMR_no.Text = row_selected[6].ToString();
                    txtAccNo.Text = row_selected[7].ToString();
                    txtAmountPaid.Text = row_selected[4].ToString();
                    txtExpenseReportID.Text = row_selected[1].ToString();
                    txtExpenseType.Text = row_selected[2].ToString();
                    txtPaymentType.Text = row_selected[5].ToString();
                    txtExpenseDate.Text = Convert.ToDateTime(row_selected[3]).ToString();
                }
            }
            catch (Emp_Exception)
            {
                MessageBox.Show("Cannot Select this row.");
            }
            catch (Exception)
            {
                MessageBox.Show("Cannot Select this row.");
            }
           
        }
    }
}
