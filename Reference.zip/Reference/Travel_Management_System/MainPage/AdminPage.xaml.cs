﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EmployeeBAL;
using EmployeeEntity;
using EmployeeException;

namespace MainPage
{
    /// <summary>
    /// Interaction logic for Page3.xaml
    /// </summary>
    public partial class AdminPage : Page
    {
        

        static string Constring = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        SqlConnection connection = new SqlConnection(Constring);
        

        public AdminPage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ExpenseBAL count = new ExpenseBAL();
            expenseRequestCount.Text = count.ExpenseRequestCount_BAL().ToString();

            TReq_BAL reqcount = new TReq_BAL();
            travelRequestCount.Text = reqcount.TravelRequestCount_BAL().ToString();

        }

        
    }
}
