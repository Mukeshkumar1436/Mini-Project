﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SignUp_BAL;
using Signup_Entities;
using SignUp_Exceptions;

namespace SignUp_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show1();
        }

        public void Clear()
        {
            txtFName.Text = "";
            txtLName.Text = "";
            txtEmail.Text = "";
            txtDob.Text = "";
            txtPwd.Password = "";
            rbMale.IsChecked = false;
            rbFemale.IsChecked = false;
            txtConPwd.Password = "";

        }
        public new void Show1()
        {
            try
            {
                List<SignupEntities> userList = SignUpBAL.RetrieveUser();

                if (userList == null || userList.Count <= 0)
                    throw new SignUpExceptions("User Details not available");
                else
                {
                    //MessageBox.Show1("");
                    //dgStudent.DataContext = userList;
                }
            }
            catch (SignUpExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public string DecodeFrom64(string encodedData)
        {
            UTF8Encoding encoder = new UTF8Encoding();
            Decoder utf8Decode = encoder.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(encodedData);
            int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            string result = new String(decoded_char);
            return result;
        }

        public static string EncodePasswordToBase64(string password)
        {
            try
            {
                byte[] encData_byte = new byte[password.Length];
                encData_byte = Encoding.UTF8.GetBytes(password);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in base64Encode" + ex.Message);
            }
        }


            private void BtnSignup_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SignupEntities user = new SignupEntities();

                user.FName = (txtFName.Text);
                user.LName = txtLName.Text;
                user.Email = txtEmail.Text;
                string gender = string.Empty;
                if (rbMale.IsChecked == true)
                {
                    gender = rbMale.Content.ToString();
                }
                else if (rbFemale.IsChecked == true)
                {
                    gender = rbFemale.Content.ToString();
                }
                user.Gender = gender;
                                                                
               
                    user.Dob = Convert.ToDateTime(txtDob.Text);
                user.pwd = EncodePasswordToBase64(txtPwd.Password.ToString());
                user.conPwd = EncodePasswordToBase64(txtConPwd.Password.ToString());

                int recordsAffected = SignUpBAL.InsertStudent(user);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Thank you "+user.LName+" "+user.FName+ "\n You are Signed Up successfully");
                    Show1();
                    Clear();
                }
                else
                    throw new SignUpExceptions("Record not inserted");
            }
            catch (SignUpExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        


    }
}
