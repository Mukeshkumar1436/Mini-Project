﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SignUp_Exceptions
{
    public class SignUpExceptions : ApplicationException 
    {
        public SignUpExceptions(string message) : base(message)
        {

        }
    }
}
