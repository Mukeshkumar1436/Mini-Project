Create TABLE FacebookSignup_172424(
FirstName varchar(20),
LastName varchar(20),
Email varchar(30),
Dob datetime,
Gender varchar(8),
Password varchar(30),
ConPassword varchar(30)
)
GO
SELECT * FROM FacebookSignup_172424

GO

ALTER PROC user_Insert
(
@FName Varchar(20),
@LName varchar(20),
@Email varchar(30),
@Dob datetime,
@Gender varchar(8),
@Password varchar(30),
@ConPassword varchar(30)	
)
AS
BEGIN
	INSERT INTO FacebookSignup_172424
	VALUES(@FName, @LName, @Email, @Dob, @Gender,@Password,@ConPassword)
END
GO

CREATE PROC user_Display
AS
BEGIN
SELECT * FROM FacebookSignup_172424
END
GO

DELETE FROM FacebookSignup_172424 where FirstName = 'Mali'