﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SignUp_DAL;
using Signup_Entities;
using System.Text.RegularExpressions;
using SignUp_Exceptions;

namespace SignUp_BAL
{
    public class SignUpBAL
    {
        public static bool ValildateUser(SignupEntities user)
        {
            bool userValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (user.FName == string.Empty)
                {
                    userValidated = false;
                    message.Append("Please Enter Your First Name !!! \n");
                }
                else if (!Regex.IsMatch(user.FName, "[A-Z][A-Z a-z]+"))
                {
                    userValidated = false;
                    message.Append("First Name should Start with Capital \n");
                }

                if (user.LName == string.Empty)
                {
                    userValidated = false;
                    message.Append("Please Enter Your Last Name !!! \n");
                }
                else if (!Regex.IsMatch(user.LName, "[A-Z][A-Z a-z]+"))
                {
                    userValidated = false;
                    message.Append("Last Name should Start with Capital \n");
                }

                if (user.Email == string.Empty)
                {
                    userValidated = false;
                    message.Append("Email Is Manditory !!! \n");
                }
                else if (!Regex.IsMatch(user.Email, @"\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}"))
                {
                    userValidated = false;
                    message.Append("Invalid Email !!! \n");
                }

                if (user.Dob == null)
                {
                    userValidated = false;
                    message.Append("Date of Birth should be provided\n");
                }
                else if (user.Dob > DateTime.Now)
                {
                    userValidated = false;
                    message.Append("Invalid Date \n");
                }
                if (user.pwd == string.Empty)
                {
                    userValidated = false;
                    message.Append("Password Should not be Empty !!! \n");
                }
                else if(user.pwd != user.conPwd)
                {
                    userValidated = false;
                    message.Append("Password Not Matched !!! \n");
                }
                //else if(!Regex.IsMatch(user.pwd, @"(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z]{8,}"))
                //{
                //    userValidated = false;
                //    message.Append("Password must contain at least one letter, at least one number, and be longer than eight charaters. \n");
                //}
                //else if (!Regex.IsMatch(Convert.ToString(user.Dob) ,@" (17 | 18)\d\d[- /.](0[1 - 9] | 1[012])[- /.](0[1 - 9] |[12][0 - 9] | 3[01])"))
                //    {

                //}

                if (userValidated == false)
                    throw new SignUpExceptions(message.ToString());
            }
            catch (SignUpExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userValidated;
        }


        public static int InsertStudent(SignupEntities user)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateUser(user))
                {
                    recordsAffected = SignUpOperations.InsertUser(user);
                }
                else
                    throw new SignUpExceptions("Please provide valid User Details");
            }
            catch (SignUpExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        public static List<SignupEntities> RetrieveUser()
        {
            List<SignupEntities> userList = null;

            try
            {
                userList = SignUpOperations.RetrieveUser();
            }
            catch (SignUpExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userList;
        }
    }
}
