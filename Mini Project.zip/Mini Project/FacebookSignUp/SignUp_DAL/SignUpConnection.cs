﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Signup_Entities;
using SignUp_Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace SignUp_DAL
{
    class SignUpConnection
    {
        public static SqlCommand GenerateCommand()
        {
            SqlCommand cmd = null;

            try
            {
                //Creating connection object
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Facebook"].ConnectionString);
 
                //Creating Command object
                cmd = new SqlCommand();

                //Assigning common properties to command
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return cmd;
        }
    }
}
