﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Signup_Entities;
using SignUp_Exceptions;
using System.Data.SqlClient;


namespace SignUp_DAL
{
    public class SignUpOperations
    {
        public static int InsertUser(SignupEntities user)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = SignUpConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "user_Insert";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@FName", user.FName);
                cmd.Parameters.AddWithValue("@LName", user.LName);
                cmd.Parameters.AddWithValue("@Email", user.Email);
                cmd.Parameters.AddWithValue("@Dob", user.Dob);
                cmd.Parameters.AddWithValue("@Gender",user.Gender);
                cmd.Parameters.AddWithValue("@Password", user.pwd);
                cmd.Parameters.AddWithValue("@ConPassword", user.conPwd);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }


        public static List<SignupEntities> RetrieveUser()
        {
            List<SignupEntities> userList = null;

            try
            {
                SqlCommand cmd = SignUpConnection.GenerateCommand();
                cmd.CommandText = "user_Display";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    userList = new List<SignupEntities>();
                    while (dr.Read())
                    {
                        SignupEntities user = new SignupEntities();

                        user.FName = dr["FirstName"].ToString();
                        user.LName = dr["LastName"].ToString();
                        user.Email = dr["Email"].ToString();
                        user.Dob = Convert.ToDateTime(dr["Dob"]);
                        user.Gender = dr["Gender"].ToString();
                        user.pwd = dr["Password"].ToString();

                        userList.Add(user);
                    }
                }
                else
                    throw new SignUpExceptions("Record not available");
                cmd.Connection.Close();
            }
            catch (SignUpExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userList;
        }
    }
}
