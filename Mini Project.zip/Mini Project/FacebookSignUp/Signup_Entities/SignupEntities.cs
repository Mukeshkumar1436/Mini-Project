﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Signup_Entities
{
    public class SignupEntities
    {
        public string FName { get; set; } 

        public string LName { get; set; }

        public string Email { get; set; }

        public DateTimeOffset Dob { get; set; }

        public string Gender { get; set; }

        public string pwd { get; set; }

        public string conPwd { get; set; }

    }
}
