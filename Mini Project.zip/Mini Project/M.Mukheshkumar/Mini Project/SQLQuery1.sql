--Creating a DataBase--
create database TMS_172435
go

use TMS_172435
--Creating a Schema--
create schema tms
go


--Create an EmployeeDetails Table--
create table tms.Employee_172435
(Employee_ID int primary key,
Employee_FirstName varchar(30),
Employee_LastName varchar(30),
Employee_Email varchar(40),
Employee_Phno varchar(10),
Location varchar(15),
Reimbursement_AccountNo varchar(15),
Password varchar(20)
)
go

select * from tms.Employee_172435
go

--Creating an Admin Details Table--
create table tms.Admin_172435
(Admin_ID int primary key ,
Admin_FirstName varchar(30),
Admin_LastName varchar(30),
Admin_Email varchar(30),
Admin_Phno varchar(10),
Password varchar(20)
)
go

select * from tms.Admin_172435


--Creating a Travel Details Table--
create table tms.Travel_Details_172435(
MR_Number int primary key identity(10000000,1),
Employee_Id int foreign key references tms.Employee_172435(Employee_ID), 
Apply_date date, 
Reason_for_Travel varchar(50),
Travel_date date,
Travel_Mode varchar(15),
FromCity varchar(20),
ToCity varchar(20),
Travel_duration int
)
go
select * from tms.Travel_Details_172435
go


--Creating a Expense Details table--
create table tms.Expense_Details_172435(
Expense_ReportId int primary key ,
Expense_Type varchar(15),
Expense_Date date,
Amount_Spent money,
Payment_Type varchar(15),
MR_Number int foreign key references tms.Travel_Details_172435(MR_Number),
Reimbursement_Account_No bigint,
Expense_Status varchar(15)
)
go

select * from tms.Expense_Details_172435
go

drop table tms.Expense_Accepted_172435
--Creating a Expense Accepted Table--
create table tms.Expense_Accepted_172435(
Expense_ReportId int primary key foreign key references tms.Expense_Details_172435(Expense_ReportId) ,
Amount_Paid money,
Payment_Date date
)
go

select * from tms.Expense_Accepted_172435
go


drop table tms.Expense_Rejected_172435
--Creating an Expense Regected Table--
create table tms.Expense_Rejected_172435(
Expense_ReportId int primary key foreign key references tms.Expense_Details_172435(Expense_ReportId),
Reason_for_Rejection varchar(50),
Rejection_Date  date
)
go

select * from tms.Expense_Rejected_172435
go



