﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TEMS_Entities
{
    public class TravelEntities
    {
        public int Mr_No { get; set; }

        public int EmpId { get; set; }

        public DateTime Apply_Date { get; set; }

        public string Reason { get; set; }

        public DateTime Travel_Date { get; set; }

        public string Travel_Mode { get; set; }

        public string FromCity { get; set; }

        public string ToCity { get; set; }

        public int Travel_dur { get; set; }
    }
}
