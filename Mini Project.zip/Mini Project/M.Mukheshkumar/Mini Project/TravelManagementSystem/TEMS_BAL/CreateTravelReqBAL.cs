﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_DAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TEMS_BAL
{
    public class CreateTravelReqBAL
    {
        public static bool ValidateReq(TravelEntities req)
        {
            bool ReqValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (req.Reason.ToString() == null)
                {
                    ReqValidated = false;
                    message.Append("Reason should be provided \n");
                }


                if (req.Travel_Date.ToString() == String.Empty)
                {
                    ReqValidated = false;
                    message.Append("Travel Date should be provided\n");
                }


                if (req.Travel_Mode == String.Empty)
                {
                    ReqValidated = false;
                    message.Append("Travel Mode should be provided\n");
                }


                if (req.FromCity == string.Empty)
                {
                    ReqValidated = false;
                    message.Append("Please enter From City \n");
                }


                if (req.ToCity == string.Empty)
                {
                    ReqValidated = false;
                    message.Append("Please enter To City \n");
                }


                if (req.Travel_dur.ToString() == null)
                {
                    ReqValidated = false;
                    message.Append("Please enter no of days \n");
                }


                if (ReqValidated == false)
                    throw new Exceptions(message.ToString());
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ReqValidated;
        }

        public static int CreateReq(TravelEntities req)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateReq(req))
                {
                    recordsAffected = CreateTravelReqDAL.CreateReq(req);
                }
                else
                    throw new Exceptions("Please provide valid req Information");
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
