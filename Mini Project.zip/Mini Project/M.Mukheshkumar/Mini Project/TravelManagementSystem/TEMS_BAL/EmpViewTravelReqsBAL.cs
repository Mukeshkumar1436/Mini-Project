﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_DAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TEMS_BAL
{
    public class EmpViewTravelReqsBAL
    {
        public static List<TravelEntities> RetrieveReqs(int empid1)
        {
            List<TravelEntities> reqList = null;

            try
            {
                reqList = EmpViewTravelReqsDAL.RetrieveTReqs(empid1);
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return reqList;
        }

        
    }
}
