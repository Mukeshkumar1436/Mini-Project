﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TEMS_BAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TravelManagementSystem
{
    /// <summary>
    /// Interaction logic for AdminLogin.xaml
    /// </summary>
    public partial class AdminLogin : Window
    {
        public static int empid1;
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                empid1 = Convert.ToInt32(txtUid.Text);

                int AdminID = Convert.ToInt32(txtUid.Text);
                string pwd = txtPwd.Password;

                UserEntity user = AdminLoginBAL.SearchAdmin(AdminID, pwd);

                if (user != null)
                {
                    AdminControls page1 = new AdminControls();
                    page1.Show();
                    this.Close();
                }
                else
                    throw new Exceptions("Invalid User");
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            };
        }

        private void Forgotpwd_Click(object sender, RoutedEventArgs e)
        {
            ResetPassword resetPassword = new ResetPassword();
            resetPassword.Show();
            Close();
        }
    }
}
