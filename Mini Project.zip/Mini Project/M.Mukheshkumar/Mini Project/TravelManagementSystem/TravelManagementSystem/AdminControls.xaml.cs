﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TravelManagementSystem
{
    /// <summary>
    /// Interaction logic for AdminControls.xaml
    /// </summary>
    public partial class AdminControls : Window
    {
        public AdminControls()
        {
            InitializeComponent();
        }

        private void hlAddemp_Click(object sender, RoutedEventArgs e)
        {
            NewUserRegistration newemployee = new NewUserRegistration();
            newemployee.Show();
            
        }

        private void hlviewTreq_Click(object sender, RoutedEventArgs e)
        {
            ViewTravelReqs page = new ViewTravelReqs();
            page.Show();
            
        }

        private void hlEdit_Click(object sender, RoutedEventArgs e)
        {
            ModifyTravelReq page = new ModifyTravelReq();
            page.Show();
        }

        private void hlTrej_Click(object sender, RoutedEventArgs e)
        {
            ApRejTravelReq page = new ApRejTravelReq();
            page.Show();
        }

        private void hlTclaim_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Home page = new Home();
            page.Show();
            this.Close();
        }
    }
}
