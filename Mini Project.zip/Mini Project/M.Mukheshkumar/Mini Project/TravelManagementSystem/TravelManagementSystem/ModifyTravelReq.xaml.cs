﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TEMS_BAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TravelManagementSystem
{
    /// <summary>
    /// Interaction logic for ModifyTravelReq.xaml
    /// </summary>
    public partial class ModifyTravelReq : Window
    {
        public ModifyTravelReq()
        {
            InitializeComponent();
        }

        public void show()
        {
            try
            {
                List<TravelEntities> reqList = ViewTravelReqsBAL.RetrieveReqs();

                if (reqList == null || reqList.Count <= 0)
                    throw new Exceptions("Records not available");
                else
                {
                    dgVTR.DataContext = reqList;
                }
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            show();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int mrno = Convert.ToInt32(txtMrNo.Text);
                TravelEntities entities = ModifyTravelReqBAL.SearchRequest(mrno);

                txtEmpId.Text = entities.EmpId.ToString();
                txtReason.Text = entities.Reason;
                txtApplyDate.Text = entities.Apply_Date.ToString();
                txtTravelDate.Text = entities.Travel_Date.ToString();
                txtTravelMode.Text = entities.Travel_Mode;
                txtFrom.Text = entities.FromCity;
                txtTo.Text = entities.ToCity;
                txtTravelDays.Text = entities.Travel_dur.ToString();

                lblEmpId.Visibility = 0;
                txtEmpId.Visibility = 0;
                lblreason.Visibility = 0;
                txtReason.Visibility = 0;
                lblApplyDate.Visibility = 0;
                txtApplyDate.Visibility = 0;
                lblTravelDate.Visibility = 0;
                txtTravelDate.Visibility = 0;
                lblTravelMode.Visibility = 0;
                txtTravelMode.Visibility = 0;
                lblFrom.Visibility = 0;
                txtFrom.Visibility = 0;
                lblTo.Visibility = 0;
                txtTo.Visibility = 0;
                lblTravelDays.Visibility = 0;
                txtTravelDays.Visibility = 0;
                
                btnUpdate.Visibility = 0;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TravelEntities req = new TravelEntities();

                req.Mr_No = Convert.ToInt32(txtMrNo.Text);
                req.Reason = txtReason.Text;
                req.Apply_Date = Convert.ToDateTime(txtApplyDate.Text);
                req.Travel_Date = Convert.ToDateTime(txtTravelDate.Text);
                req.Travel_Mode = txtTravelMode.Text;
                req.FromCity = txtFrom.Text;
                req.ToCity = txtTo.Text;
                req.Travel_dur = Convert.ToInt32(txtTravelDays.Text);


                int recordsAffected = ModifyTravelReqBAL.UpdateReq(req);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Travel Details updated successfully");
                    Show();

                }
                else
                    throw new Exceptions("Travel Details not Updated");
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }
    }
}
