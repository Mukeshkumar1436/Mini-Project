﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TEMS_BAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TravelManagementSystem
{
    /// <summary>
    /// Interaction logic for NewUserRegistration.xaml
    /// </summary>
    public partial class NewUserRegistration : Window
    {
        public NewUserRegistration()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            AdminControls page = new AdminControls();
            page.Show();
            this.Close();
        }

        public void clear()
        {
            txtEmpId.Text = "";
            txtEmpFName.Text = "";
            txtEmpLName.Text = "";
            txtEmail.Text = "";
            txtEmpPhNo.Text = "";
            txtLoc.Text = "";
            txtrmbAcc.Text = "";
            txtPass.Password = "";

        }

        private void BtnAdmLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                RegistrationEntities user = new RegistrationEntities();

                user.EmpID = Convert.ToInt32(txtEmpId.Text);
                user.FirstName = txtEmpFName.Text;
                user.Lastname = txtEmpLName.Text;
                user.Email = (txtEmail.Text);
                user.PhNo = (txtEmpPhNo.Text);
                user.Location = txtLoc.Text;
                user.RAcNo = txtrmbAcc.Text;
                user.Password = txtPass.Password;

                int recordsAffected = RegistrationBAL.InsertUser(user);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("New Employee created successfully");
                    Show();
                    clear();
                }
                else
                    throw new Exceptions("New Employee not created");
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
