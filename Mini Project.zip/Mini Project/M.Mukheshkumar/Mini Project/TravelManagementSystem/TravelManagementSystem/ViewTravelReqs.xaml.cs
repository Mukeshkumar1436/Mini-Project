﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TEMS_BAL;
using TEMS_Entities;
using TEMS_Exceptions;


namespace TravelManagementSystem
{
    /// <summary>
    /// Interaction logic for ViewTravelReqs.xaml
    /// </summary>
    public partial class ViewTravelReqs : Window
    {
        public ViewTravelReqs()
        {
            InitializeComponent();
        }


        public void show()
        {
            try
            {
                List<TravelEntities> reqList = ViewTravelReqsBAL.RetrieveReqs();

                if (reqList == null || reqList.Count <= 0)
                    throw new Exceptions("Records not available");
                else
                {
                    dgVTR.DataContext = reqList;
                }
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            show();
        }
    }
}
