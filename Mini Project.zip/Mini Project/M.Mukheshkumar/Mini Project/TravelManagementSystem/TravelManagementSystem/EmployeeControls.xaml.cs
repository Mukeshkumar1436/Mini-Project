﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TravelManagementSystem
{
    /// <summary>
    /// Interaction logic for EmployeeControls.xaml
    /// </summary>
    public partial class EmployeeControls : Window
    {
        public EmployeeControls()
        {
            InitializeComponent();
        }

        private void Logout_Click_1(object sender, RoutedEventArgs e)
        {
            Home page = new Home();
            page.Show();
            this.Close();
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            EditEmployeeInformation page = new EditEmployeeInformation();
            page.Show();
            
        }

        
        private void CreateTravelReq_Click_2(object sender, RoutedEventArgs e)
        {
            CreateTravelReq page = new CreateTravelReq();
            page.Show();
            
        }

        private void SearchTravelReq_Click(object sender, RoutedEventArgs e)
        {
            EmployeeViewTravelReqs page = new EmployeeViewTravelReqs();
            page.Show();

        }

        private void CheckTravelReq_Click(object sender, RoutedEventArgs e)
        {
            TravelReqApprovalStatus page = new TravelReqApprovalStatus();
            page.Show();
            
        }
        
        private void CreateExpenseClaim_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void ViewReport(object sender, RoutedEventArgs e)
        {

        }
    }
}
