﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_Entities;
using TEMS_Exceptions;
using System.Data.SqlClient;

namespace TEMS_DAL
{
    public class EmpRegOperations
    {
        public static int Insertuser(RegistrationEntities user)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = TEMS_Connections.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "New_Employee_172435";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@empId", user.EmpID);
                cmd.Parameters.AddWithValue("@empFName", user.FirstName);
                cmd.Parameters.AddWithValue("@empLName", user.Lastname);
                cmd.Parameters.AddWithValue("@empEmail", user.Email);
                cmd.Parameters.AddWithValue("@empPhNo", user.PhNo);
                cmd.Parameters.AddWithValue("@empLoc", user.Location);
                cmd.Parameters.AddWithValue("@empRAcNo", user.RAcNo);
                cmd.Parameters.AddWithValue("@pwd", user.Password);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
