﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_Entities;
using TEMS_Exceptions;
using System.Data.SqlClient;

namespace TEMS_DAL
{
    public class TEMS_AdminLoginDAL
    {
        public static UserEntity SearchAdmin(int AdminId, string pwd)
        {
            UserEntity user = null;

            try
            {
                SqlCommand cmd = TEMS_Connections.GenerateCommand();

                cmd.CommandText = "Admin_Login_Valid";
                cmd.Parameters.AddWithValue("@Admin_Id", AdminId);
                cmd.Parameters.AddWithValue("@Password", pwd);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    user = new UserEntity();
                    dr.Read();
                    user.Emp_Id = (int)dr["Admin_ID"];
                    user.Emp_password = dr["Password"].ToString();
                    
                }
                else
                {
                    throw new Exceptions("Invalid User!!");
                }
                cmd.Connection.Close();
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return user;
        }
    }
}
