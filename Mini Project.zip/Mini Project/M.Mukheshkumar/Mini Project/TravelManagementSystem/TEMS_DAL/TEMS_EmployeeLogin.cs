﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_Entities;
using TEMS_Exceptions;
using System.Data.SqlClient;

namespace TEMS_DAL
{
    public class TEMS_EmployeeLogin
    {
        public static UserEntity SearchUser(int EmpId, string pwd)
        {
            UserEntity user = null;

            try
            {
                SqlCommand cmd = TEMS_Connections.GenerateCommand();

                cmd.CommandText = "Emp_Login_Valid";
                cmd.Parameters.AddWithValue("@Emp_Id", EmpId);
                cmd.Parameters.AddWithValue("@Password", pwd);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    user = new UserEntity();
                    dr.Read();
                    user.Emp_Id = (int)dr["Employee_ID"];
                    user.Emp_password = dr["Password"].ToString();
                    //stud.DCode = (int)dr["Dept_Code"];
                    //stud.Dob = Convert.ToDateTime(dr["Dob"]);
                    //stud.Address = dr["Address"].ToString();
                }
                else
                {
                    throw new Exceptions("Invalid User!!");
                }
                cmd.Connection.Close();
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return user;
        }
    }
}
