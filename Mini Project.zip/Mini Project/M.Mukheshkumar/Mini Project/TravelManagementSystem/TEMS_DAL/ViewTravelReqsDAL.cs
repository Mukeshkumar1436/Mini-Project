﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TEMS_DAL
{
    public class ViewTravelReqsDAL
    {
        public static List<TravelEntities> RetrieveTReqs()
        {
            List<TravelEntities> reqs = null;

            try
            {
                SqlCommand cmd = TEMS_Connections.GenerateCommand();
                cmd.CommandText = "DisplayTravelReqs_172435";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    reqs = new List<TravelEntities>();
                    while (dr.Read())
                    {
                        TravelEntities req = new TravelEntities();

                        req.Mr_No = (int)dr["MR_Number"];
                        req.EmpId = (int)dr["Employee_Id"];
                        req.Apply_Date = Convert.ToDateTime(dr["Apply_date"]);
                        req.Reason = dr["Reason_for_Travel"].ToString();
                        req.Travel_Date = Convert.ToDateTime(dr["Travel_date"]);
                        req.Travel_Mode = dr["Travel_Mode"].ToString();
                        req.FromCity = dr["FromCity"].ToString();
                        req.ToCity = dr["ToCity"].ToString();
                        req.Travel_dur = (int)dr["Travel_duration"];

                        reqs.Add(req);
                        
                    }
                }
                else
                    throw new Exceptions("Record not available");
                cmd.Connection.Close();
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return reqs;
        }
    }
}
