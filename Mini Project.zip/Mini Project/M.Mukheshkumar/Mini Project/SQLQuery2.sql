use TMS_172435


--Stored Procedure for Emoployee Login--
create PROC Emp_Login_Valid
(
	@Emp_Id		INT,
	@Password varchar(20)
)
AS
BEGIN
	SELECT * FROM tms.Employee_172435
	WHERE Employee_ID = @Emp_Id and Password = @Password
END

GO


--Stored Procedure for Admin Login--
create PROC Admin_Login_Valid
(
	@Admin_Id		INT,
	@Password varchar(20)
)
AS
BEGIN
	SELECT * FROM tms.Admin_172435
	WHERE Admin_Id = @Admin_Id and Password = @Password
END
insert into tms.Admin_172435 values(172435,'Mukesh@5')

select * from tms.Admin_172435
insert into tms.Admin_172435 values(172435,'Mukhesh','Kumar','mukheshmanthena9@gmail.com',8686658438,'Mukesh@5')
GO

--Stored Procedure for new Employee--
create proc New_Employee_172435
( 
@empId int,
@empFName varchar(30),
@empLName varchar(30),
@empEmail varchar(40),
@empPhNo varchar(10),
@empLoc varchar(15),
@empRAcNo varchar(15),
@pwd varchar(20)
)
AS
BEGIN
	INSERT INTO tms.Employee_172435 VALUES(@empId, @empFName, @empLName, @empEmail, @empPhNo, @empLoc, @empRAcNo, @pwd)
END
GO


--Stored Procdure for Update--
create proc Update_Profile_172435
(
@empId int,
@empFName varchar(30),
@empLName varchar(30),
@empEmail varchar(40),
@empPhNo varchar(10),
@empLoc varchar(15),
@empRAcNo varchar(15),
@pwd varchar(20)
)
AS
BEGIN 
	UPDATE tms.Employee_172435
	SET Employee_FirstName = @empFName,
	  Employee_LastName= @empLName,
	  Employee_Email= @empEmail,
	  Employee_Phno=@empPhNo,
	  Location=@empLoc,
	  Reimbursement_AccountNo=@empRAcNo,
	  Password=@pwd
	  WHERE Employee_ID = @empId
	  END
	  GO


--Stored Procedure for Retrieve--
Create proc Retrieve_User_172435(@empid int )
as begin
select * from tms.Employee_172435 where Employee_ID=@empid
end


--Stored Procedure for Travel Request--
CREATE PROC CreateTravelRequest_172435
(

@empid int, 
@applyDate date, 
@reasonforTravel varchar(50),
@travelDate date,
@travelMode varchar(15),
@fromCity varchar(20),
@toCity varchar(20),
@travelDuration int
)
AS BEGIN 
INSERT INTO tms.Travel_Details_172435 VALUES(@empid,@applyDate,@reasonforTravel,@travelDate,@travelMode,@fromCity,@toCity,@travelDuration)
END
go

select * from tms.Travel_Details_172435


--Stored Procedure for Display--
create proc DisplayTravelReqs_172435
as 
begin
select * from tms.Travel_Details_172435
end
go

create proc DisplayEmpTravelReqs_172435
(
@empid int
)
as 
begin
select * from tms.Travel_Details_172435 where Employee_Id = @empid
end
go


--Stored Procedure for Search--
create proc Search_Request_172435(@mrno int )
as begin
select * from tms.Travel_Details_172435 where MR_Number = @mrno
end
go


--Stored Procedure for Updating Travel Request--
CREATE PROC UpdateTravelRequest_172435
( 
@mrno int,
@applyDate date, 
@reasonforTravel varchar(50),
@travelDate date,
@travelMode varchar(15),
@fromCity varchar(20),
@toCity varchar(20),
@travelDuration int
)
AS BEGIN 
Update tms.Travel_Details_172435 
	set
	Apply_date = @applyDate,
	Reason_for_Travel= @reasonforTravel,
	Travel_date = @travelDate,
	Travel_Mode = @travelMode,
	FromCity = @fromCity,
	ToCity = @toCity,
	Travel_duration = @travelDuration
	WHERE MR_Number = @mrno
END
go