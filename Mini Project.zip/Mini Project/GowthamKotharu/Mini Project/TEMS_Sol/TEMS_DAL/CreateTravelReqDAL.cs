﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_Entities;
using TEMS_Exceptions;
using System.Data.SqlClient;

namespace TEMS_DAL
{
    public class CreateTravelReqDAL
    {
        public static int CreateReq(TravelEntities req)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = TEMS_Connections.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "CreateTravelRequest_172424";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@empid", req.EmpId);
                cmd.Parameters.AddWithValue("@applyDate", req.Apply_Date);
                cmd.Parameters.AddWithValue("@reasonforTravel", req.Reason);
                cmd.Parameters.AddWithValue("@travelDate", req.Travel_Date);
                cmd.Parameters.AddWithValue("@travelMode", req.Travel_Mode);
                cmd.Parameters.AddWithValue("@fromCity", req.FromCity);
                cmd.Parameters.AddWithValue("@toCity", req.ToCity);
                cmd.Parameters.AddWithValue("@travelDuration", req.Travel_dur);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
