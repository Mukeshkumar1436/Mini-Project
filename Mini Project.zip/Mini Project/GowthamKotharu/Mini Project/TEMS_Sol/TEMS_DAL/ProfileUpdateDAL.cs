﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_Entities;
using TEMS_Exceptions;
using System.Data.SqlClient;


namespace TEMS_DAL
{
    public class ProfileUpdateDAL
    {
        public static int UpdateUser(RegistrationEntities user)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = TEMS_Connections.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "Update_Profile_172424";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@empId", user.EmpID);
                cmd.Parameters.AddWithValue("@empFName", user.FirstName);
                cmd.Parameters.AddWithValue("@empLName", user.Lastname);
                cmd.Parameters.AddWithValue("@empEmail", user.Email);
                cmd.Parameters.AddWithValue("@empPhNo", user.PhNo);
                cmd.Parameters.AddWithValue("@empLoc", user.Location);
                cmd.Parameters.AddWithValue("@empRAcNo", user.RAcNo);
                cmd.Parameters.AddWithValue("@pwd", user.Password);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static RegistrationEntities RetrieveUser(int empid)
        {
           RegistrationEntities user = null;

            try
            {
                SqlCommand cmd = TEMS_Connections.GenerateCommand();
                cmd.CommandText = "Retrieve_User_172424";
                cmd.Parameters.AddWithValue("@empid", empid);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    user = new RegistrationEntities();
                    dr.Read();

                    user.EmpID = (int)dr["Employee_ID"];
                    user.FirstName = dr["Employee_FirstName"].ToString();
                    user.Lastname = dr["Employee_LastName"].ToString();
                    user.Email = dr["Employee_Email"].ToString();
                    user.PhNo = dr["Employee_Phno"].ToString();
                    user.Location = dr["Location"].ToString();
                    user.RAcNo = dr["Reimbursement_AccountNo"].ToString();
                    user.Password = dr["Password"].ToString();

                }
                else
                {
                    throw new Exceptions("User details not available");  
                }
                cmd.Connection.Close();
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return user;
        }
    }

}
