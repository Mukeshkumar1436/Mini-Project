﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TEMS_Entities
{
    public class RegistrationEntities
    {
        public int EmpID { get; set; }

        public string FirstName { get; set; }

        public string Lastname { get; set; }

        public string Email { get; set; }

        public string PhNo { get; set; }

        public string Location { get; set; }

        public string RAcNo { get; set; }

        public string Password { get; set; }
    }
}
