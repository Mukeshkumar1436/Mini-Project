﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TEMS_Entities
{
    public  class UserEntity
    {
        public int Emp_Id {get; set;}
        public  string Emp_password { get; set; }
    }
    
}
