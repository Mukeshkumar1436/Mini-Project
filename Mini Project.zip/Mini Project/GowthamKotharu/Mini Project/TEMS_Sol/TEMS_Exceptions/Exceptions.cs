﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TEMS_Exceptions
{
    public class Exceptions : Exception
    {
        public Exceptions(string message) : base(message)
        {

        }
    }
}
