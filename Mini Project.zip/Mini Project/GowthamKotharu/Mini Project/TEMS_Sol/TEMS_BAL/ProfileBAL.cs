﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_DAL;
using System.Text.RegularExpressions;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TEMS_BAL
{
    public class ProfileBAL
    {

        public static bool Valildateuser(RegistrationEntities user)
        {
            bool userValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
               
                if (user.FirstName == String.Empty)
                {
                    userValidated = false;
                    message.Append("First name should be provided\n");
                }
                else if (!Regex.IsMatch(user.FirstName, "[A-Z][a-z]+"))
                {
                    userValidated = false;
                    message.Append("First Name should Start with Capitals only\n");
                }

                if (user.Lastname == String.Empty)
                {
                    userValidated = false;
                    message.Append("Last name should be provided\n");
                }
                else if (!Regex.IsMatch(user.Lastname, "[A-Z][a-z]+"))
                {
                    userValidated = false;
                    message.Append("Last Name should Start with Capitals only\n");
                }

                if (user.Email == string.Empty)
                {
                    userValidated = false;
                    message.Append("Email Should be Provided \n");
                }
                else if (!Regex.IsMatch(user.Email, @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"))
                {
                    userValidated = false;
                    message.Append("Invalid Email Id\n");
                }

                if (user.PhNo == string.Empty)
                {
                    userValidated = false;
                    message.Append("Phone Number should be provided\n");
                }
                else if (!Regex.IsMatch(user.PhNo, "[6 7 8 9][0-9]{9}"))
                {
                    userValidated = false;
                    message.Append("Invalid Phone Number\n");
                }

                if (user.Location == string.Empty)
                {
                    userValidated = false;
                    message.Append("Location should be provided\n");
                }

                if (user.RAcNo == string.Empty)
                {
                    userValidated = false;
                    message.Append("Reimbursement Account No should be provided\n");
                }
                else if (!Regex.IsMatch(user.RAcNo, "[0-9]{11}"))
                {
                    userValidated = false;
                    message.Append("Reimbursement Account No should be 11 Digits");
                }
                if (user.Password == string.Empty)
                {
                    userValidated = false;
                    message.Append("Password should be provided\n");
                }
                else if (!Regex.IsMatch(user.Password, @"(?=^.{8,255}$)((?=.*\d)(?=.*[A-Z])(?=.*[a-z])|(?=.*\d)(?=.*[^A-Za-z0-9])(?=.*[a-z])|(?=.*[^A-Za-z0-9])(?=.*[A-Z])(?=.*[a-z])|(?=.*\d)(?=.*[A-Z])(?=.*[^A-Za-z0-9]))^.*"))
                {
                    userValidated = false;
                    message.Append("Password must contain at least one Uppercase or lowercase character, at least 1 special character, at least one number, and must be min 8 characters longer.");
                }

                if (userValidated == false)
                    throw new Exceptions(message.ToString());
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userValidated;
        }


        public static int UpdateUser(RegistrationEntities user)
        {
            int recordsAffected = 0;

            try
            {
                if (Valildateuser(user))
                {
                    recordsAffected = ProfileUpdateDAL.UpdateUser(user);
                }
                else
                    throw new Exceptions("Please provide valid User Information");
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static RegistrationEntities RetriveUser(int id)
        {
            RegistrationEntities user = null;

            try
            {
               user = ProfileUpdateDAL.RetrieveUser(id);
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return user;
        }
    }
}
