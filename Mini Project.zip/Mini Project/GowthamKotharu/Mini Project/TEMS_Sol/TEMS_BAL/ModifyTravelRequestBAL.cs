﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_DAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TEMS_BAL
{

    public class ModifyTravelRequestBAL
    {
        public static bool ValidateReq(TravelEntities req)
        {
            bool ReqValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (req.Reason.ToString() == null)
                {
                    ReqValidated = false;
                    message.Append("Reason should be provided \n");
                }


                if (req.Travel_Date.ToString() == String.Empty)
                {
                    ReqValidated = false;
                    message.Append("Travel Date should be provided\n");
                }


                if (req.Travel_Mode == String.Empty)
                {
                    ReqValidated = false;
                    message.Append("Travel Mode should be provided\n");
                }


                if (req.FromCity == string.Empty)
                {
                    ReqValidated = false;
                    message.Append("Please enter From City \n");
                }


                if (req.ToCity == string.Empty)
                {
                    ReqValidated = false;
                    message.Append("Please enter To City \n");
                }


                if (req.Travel_dur.ToString() == null)
                {
                    ReqValidated = false;
                    message.Append("Please enter no of days \n");
                }


                if (ReqValidated == false)
                    throw new Exceptions(message.ToString());
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ReqValidated;
        }

        public static List<TravelEntities> RetrieveReqs()
        {
            List<TravelEntities> reqList = null;

            try
            {
                reqList = ViewTravelReqsDAL.RetrieveTReqs();
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return reqList;
        }

        public static int UpdateReq(TravelEntities req)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateReq(req))
                {
                    recordsAffected = ModifyTravelRequsetDAL.Updatereq(req);
                }
                else
                    throw new Exceptions("Please provide valid Travel request Information");
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static TravelEntities SearchRequest(int mrno)
        {
            TravelEntities req = null;

            try
            {
                req = ModifyTravelRequsetDAL.SearchReq(mrno);
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return req;
        }
    }
}
