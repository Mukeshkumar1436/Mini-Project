﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TEMS_DAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TEMS_BAL
{
    public class LoginBAL
    {
        public static UserEntity SearchUser(int EmpId,string pwd)
        {
            UserEntity user = null;

            try
            {
                user = TEMS_Login.SearchUser(EmpId,pwd);
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return user;
        }
        public static UserEntity SearchAdmin(int AdminId, string pwd)
        {
            UserEntity user = null;

            try
            {
                user = TEMS_Login.SearchAdmin(AdminId, pwd);
            }
            catch (Exceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return user;
        }
    }
}
