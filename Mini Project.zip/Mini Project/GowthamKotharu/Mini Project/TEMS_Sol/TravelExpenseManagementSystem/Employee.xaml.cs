﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TEMS_BAL;
using TEMS_Entities;
using TEMS_Exceptions;
using TravelExpenseManagementSystem;

namespace TravelExpenseManagementSystem
{
    /// <summary>
    /// Interaction logic for Employee.xaml
    /// </summary>
    public partial class Employee : Window
    {
        public Employee()
        {
           
            InitializeComponent();

            welcome.Content = Home.empid1;
        }

        private void Lbl1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Profile profilePage = new Profile();
            profilePage.Show();
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Profile page = new Profile();
            page.Show();
        }

        private void Hyperlink_Click_1(object sender, RoutedEventArgs e)
        {
            Home homePage = new Home();
            homePage.Show();
            this.Close();
        }

        private void Hyperlink_Click_2(object sender, RoutedEventArgs e)
        {
            CreateTravelRequest page = new CreateTravelRequest();
            page.Show();
            
        }
    }
}
