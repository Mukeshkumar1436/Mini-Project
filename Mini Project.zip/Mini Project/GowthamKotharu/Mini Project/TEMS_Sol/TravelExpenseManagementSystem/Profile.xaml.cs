﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TEMS_BAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TravelExpenseManagementSystem
{
    /// <summary>
    /// Interaction logic for Profile.xaml
    /// </summary>
    public partial class Profile : Window
    {
        public Profile()
        {
            InitializeComponent();
        }      

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                RegistrationEntities user = new RegistrationEntities();

                user.EmpID = Home.empid1;
                user.FirstName = txtFName.Text;
                user.Lastname = txtLName.Text;
                user.Email = txtEmail.Text;
                user.PhNo = txtPhone.Text;
                user.Location = txtLoc.Text;
                user.RAcNo = txtAccNo.Text;
                user.Password = txtpassword.Text;


                int recordsAffected = ProfileBAL.UpdateUser(user);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();
                    Profile page = new Profile();
                    page.Show();
                    this.Close();
                }
                else
                    throw new Exceptions("Record not updated");
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

       
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            int id = Home.empid1;
            RegistrationEntities entities = ProfileBAL.RetriveUser(id);

            txtFName.Text = entities.FirstName;
            txtLName.Text = entities.Lastname;
            txtEmail.Text = entities.Email;
            txtPhone.Text = entities.PhNo;
            txtLoc.Text = entities.Location;
            txtAccNo.Text = entities.RAcNo;
            txtpassword.Text = entities.Password;

        }
    }
}
