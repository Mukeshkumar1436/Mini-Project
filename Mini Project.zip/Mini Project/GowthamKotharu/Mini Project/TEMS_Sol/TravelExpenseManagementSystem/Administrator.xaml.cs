﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TEMS_BAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TravelExpenseManagementSystem
{
    /// <summary>
    /// Interaction logic for Administrator.xaml
    /// </summary>
    public partial class Administrator : Window
    {
        public Administrator()
        {
            InitializeComponent();
            
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Home homePage = new Home();
            homePage.Show();
            this.Close();
        }

        private void Hyperlink_Click_1(object sender, RoutedEventArgs e)
        {
            EmployeeRegistration page = new EmployeeRegistration();
            page.Show();
            
        }

        private void Hyperlink_Click_2(object sender, RoutedEventArgs e)
        {
            ViewTravelReqs page1 = new ViewTravelReqs();
            page1.Show();
        }

        private void Hyperlink_Click_3(object sender, RoutedEventArgs e)
        {
            ModifyTravelRequest page = new ModifyTravelRequest();
            page.Show();
        }
    }
}
