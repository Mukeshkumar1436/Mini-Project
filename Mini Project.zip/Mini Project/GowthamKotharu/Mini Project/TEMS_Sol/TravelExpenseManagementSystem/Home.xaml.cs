﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TEMS_BAL;
using TEMS_Entities;
using TEMS_Exceptions;

namespace TravelExpenseManagementSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Home : Window
    {
        public static int empid1;

        public Home()
        {          

        InitializeComponent();
            
        }

       
        private void BtnAdmLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                empid1 = Convert.ToInt32(txtUName.Text);
                
                int AdminID = Convert.ToInt32(txtUName.Text);
                string pwd = txtPwd.Password;

                UserEntity user = LoginBAL.SearchAdmin(AdminID, pwd);

                if (user != null)
                {
                    Administrator page1 = new Administrator();
                    page1.Show();
                    this.Close();
                }
                else
                    throw new Exceptions("Invalid User");
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
            
        }



        public void BtnEmpLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                empid1=Convert.ToInt32(txtUName.Text);
                int EmpID = Convert.ToInt32(txtUName.Text);
                string pwd = txtPwd.Password;

                UserEntity user = LoginBAL.SearchUser(EmpID,pwd);
                                 
                if (user != null)
                {
                    Employee page = new Employee();
                    page.Show();
                    this.Close();
                }
                else
                    throw new Exceptions("Invalid User");
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            
            
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            ForgotPassword page2 = new ForgotPassword();
            page2.Show();
            this.Close();
            
        }
    }
}
