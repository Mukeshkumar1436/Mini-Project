﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TEMS_BAL;
using TEMS_Entities;
using TEMS_Exceptions;


namespace TravelExpenseManagementSystem
{
    /// <summary>
    /// Interaction logic for CreateTravelRequest.xaml
    /// </summary>
    public partial class CreateTravelRequest : Window
    {
        public CreateTravelRequest()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtApplyDate.Text = DateTime.Now.ToString();
            txtEmpID.Text = Home.empid1.ToString();

        }

        private void BtnGenerateRqst_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TravelEntities req = new TravelEntities();

                req.EmpId = Home.empid1;
                req.Apply_Date = Convert.ToDateTime(DateTime.Now);
                req.Reason = txtReason.Text;
                req.Travel_Date = Convert.ToDateTime(txtTravelDate.Text);
                req.Travel_Mode = cbTravelMode.Text;
                req.FromCity = txtFrmCity.Text;
                req.ToCity = txtToCity.Text;

                req.Travel_dur = Convert.ToInt32(txtDuration.Text);

                int recordsAffected = CreateTravelReqBAL.CreateReq(req);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Employee Added successfully");
                    //Employee page = new Employee();
                    //page.Show();
                    //this.Close();
                }
                else
                    throw new Exceptions("Employee details not inserted");
            }
            catch (Exceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btncancel_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
