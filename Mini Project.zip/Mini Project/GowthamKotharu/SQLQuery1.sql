create database TMS_172424
go

create schema tms
go




create table tms.Employee_172424
(Employee_ID int primary key,
Employee_FirstName varchar(30),
Employee_LastName varchar(30),
Employee_Email varchar(40),
Employee_Phno varchar(10),
Location varchar(15),
Reimbursement_AccountNo varchar(15),
Password varchar(20)
)
go

select * from tms.Employee_172424
go






create table tms.Admin_172424
(Admin_ID int primary key ,
Admin_FirstName varchar(30),
Admin_LastName varchar(30),
Admin_Email varchar(30),
Admin_Phno varchar(10),
Password varchar(20)
)
go

select * from tms.Admin_172424
go






create table tms.Travel_Details_172424(
MR_Number int primary key identity(10000000,1),
Employee_Id int foreign key references tms.Employee_172424(Employee_ID), 
Apply_date date, 
Reason_for_Travel varchar(50),
Travel_date date,
Travel_Mode varchar(15),
FromCity varchar(20),
ToCity varchar(20),
Travel_duration int
)
go

select * from tms.Travel_Details_172424
go





create table tms.Expense_Details_172424(
Expense_ReportId int primary key ,
Expense_Type varchar(15),
Expense_Date date,
Amount_Spent money,
Payment_Type varchar(15),
MR_Number varchar(10) foreign key references tms.Travel_Details_172424(MR_Number),
Reimbursement_Account_No bigint,
Expense_Status varchar(15)
)
go

select * from tms.Expense_Details_172424
go






create table tms.Expense_Accepted_172424(
Expense_ReportId varchar(10) foreign key references tms.Expense_Details_172424(Expense_ReportId) ,
Amount_Paid money,
Payment_Date date
)
go

select * from tms.Expense_Accepted_172424
go







create table tms.Expense_Rejected_172424(
Expense_ReportId varchar(10) foreign key references tms.Expense_Details_172424(Expense_ReportId),
Reason_for_Rejection varchar(50),
Rejection_Date  date
)
go

select * from tms.Expense_Rejected_172424
go


