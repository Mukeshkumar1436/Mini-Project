use TMS_172424

create PROC Emp_Login_Valid
(
	@Emp_Id		INT,
	@Password varchar(20)
)
AS
BEGIN
	SELECT * FROM tms.Employee_172424
	WHERE Employee_ID = @Emp_Id and Password = @Password
END

GO



create PROC Admin_Login_Valid
(
	@Admin_Id		INT,
	@Password varchar(20)
)
AS
BEGIN
	SELECT * FROM tms.Admin_172424
	WHERE Admin_ID = @Admin_Id and Password = @Password
END

GO




create proc New_Employee_172424
( 
@empId int,
@empFName varchar(30),
@empLName varchar(30),
@empEmail varchar(40),
@empPhNo varchar(10),
@empLoc varchar(15),
@empRAcNo varchar(15),
@pwd varchar(20)
)
AS
BEGIN
	INSERT INTO tms.Employee_172424 VALUES(@empId, @empFName, @empLName, @empEmail, @empPhNo, @empLoc, @empRAcNo, @pwd)
END
GO




create proc Update_Profile_172424
(
@empId int,
@empFName varchar(30),
@empLName varchar(30),
@empEmail varchar(40),
@empPhNo varchar(10),
@empLoc varchar(15),
@empRAcNo varchar(15),
@pwd varchar(20)
)
AS
BEGIN 
	UPDATE tms.Employee_172424
	SET Employee_FirstName = @empFName,
	  Employee_LastName= @empLName,
	  Employee_Email= @empEmail,
	  Employee_Phno=@empPhNo,
	  Location=@empLoc,
	  Reimbursement_AccountNo=@empRAcNo,
	  Password=@pwd
	  WHERE Employee_ID = @empId
	  END
	  GO

aLTER proc Retrieve_User_172424(@empid int )
as begin
select * from tms.Employee_172424 where Employee_ID=@empid
end





CREATE PROC CreateTravelRequest_172424
(

@empid int, 
@applyDate date, 
@reasonforTravel varchar(50),
@travelDate date,
@travelMode varchar(15),
@fromCity varchar(20),
@toCity varchar(20),
@travelDuration int
)
AS BEGIN 
INSERT INTO tms.Travel_Details_172424 VALUES(@empid,@applyDate,@reasonforTravel,@travelDate,@travelMode,@fromCity,@toCity,@travelDuration)
END
go



create proc DisplayTravelReqs_172424
as 
begin
select * from tms.Travel_Details_172424
end
go

create proc Search_Request_172424(@mrno int )
as begin
select * from tms.Travel_Details_172424 where MR_Number = @mrno
end
go

CREATE PROC UpdateTravelRequest_172424
( 
@mrno int,
@applyDate date, 
@reasonforTravel varchar(50),
@travelDate date,
@travelMode varchar(15),
@fromCity varchar(20),
@toCity varchar(20),
@travelDuration int
)
AS BEGIN 
Update tms.Travel_Details_172424 
	set
	Apply_date = @applyDate,
	Reason_for_Travel= @reasonforTravel,
	Travel_date = @travelDate,
	Travel_Mode = @travelMode,
	FromCity = @fromCity,
	ToCity = @toCity,
	Travel_duration = @travelDuration
	WHERE MR_Number = @mrno
END
go